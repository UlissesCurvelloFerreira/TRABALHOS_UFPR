#ifndef LIB_REDE_H
#define LIB_REDE_H

#include <stdint.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h>

#define MAX_PAYLOAD_SIZE 127
#define MARCADOR_INICIO 0x7E
#define PROTOCOLO_CUSTOM 0x88B5

// Parâmetros do protocolo stop-and-wait
#define TIMEOUT_INICIAL 1       // Timeout inicial em segundos
#define TIMEOUT_MAXIMO 10       // Timeout máximo em segundos
#define MAX_RETRANSMISSOES 10   // Número máximo de tentativas de retransmissão
#define WINDOW_SIZE 1           // Tamanho da janela (stop-and-wait = 1)
#define SEQ_NUM_BITS 5          // Número de bits para o campo de sequência
#define SEQ_NUM_MAX ((1 << SEQ_NUM_BITS) - 1) // Valor máximo do número de sequência (31)

// Parâmetros para descoberta de MAC
#define DISCOVERY_INTERVAL 2    // Intervalo em segundos para anúncios de descoberta
#define MAX_DISCOVERY_ATTEMPTS 30 // Número máximo de tentativas de descoberta
#define MAC_EXPIRY_TIME 60      // Tempo em segundos para expirar um MAC descoberto

// Endereço MAC de broadcast
extern const uint8_t MAC_BROADCAST[6];

// Tipos de mensagem
enum {
    TIPO_ACK = 0,
    TIPO_NACK = 1,
    TIPO_OK_ACK = 2,
    TIPO_LIVRE_3 = 3,
    TIPO_TAMANHO = 4,
    TIPO_DADOS = 5,
    TIPO_TEXTO_ACK_NOME = 6,
    TIPO_VIDEO_ACK_NOME = 7,
    TIPO_IMAGEM_ACK_NOME = 8,
    TIPO_FIM_ARQUIVO = 9,
    TIPO_DESLOCA_DIREITA = 10,
    TIPO_DESLOCA_CIMA = 11,
    TIPO_DESLOCA_BAIXO = 12,
    TIPO_DESLOCA_ESQUERDA = 13,
    TIPO_LIVRE_14 = 14,
    TIPO_ERRO = 15,
    TIPO_ANUNCIO_SERVIDOR = 16,
    TIPO_DESCOBERTA_CLIENTE = 17
};

// Códigos de erro
enum {
    ERRO_SEM_PERMISSAO = 0,
    ERRO_ESPACO_INSUFICIENTE = 1,
    ERRO_TIMEOUT = 2,
    ERRO_MAX_RETRANSMISSOES = 3,
    ERRO_DESCOBERTA_MAC = 4
};

typedef struct {
    uint8_t marcador_inicio; // 0x7E
    uint8_t tamanho;         // Tamanho dos dados (0-127)
    uint8_t sequencia_tipo;  // 5 bits para sequência, 3 bits para tipo
    uint8_t checksum;        // Checksum
    uint8_t dados[MAX_PAYLOAD_SIZE]; // Carga útil
} Frame;

// Estado da conexão para controle de fluxo
typedef struct {
    uint8_t ultima_seq_enviada;     // Última sequência enviada
    uint8_t ultima_seq_confirmada;  // Última sequência confirmada (ACK recebido)
    uint8_t proxima_seq_envio;      // Próxima sequência a ser enviada
    uint8_t ultima_seq_recebida;    // Última sequência recebida corretamente
    uint8_t ultima_tipo_enviado;    // Último tipo de frame enviado
    uint8_t ultimo_tamanho_enviado; // Último tamanho de dados enviado
    uint8_t dados_ultimo_frame[MAX_PAYLOAD_SIZE]; // Cópia dos dados do último frame enviado
    int timeout_atual;              // Timeout atual em segundos (para backoff exponencial)
    int retransmissoes;             // Contador de retransmissões do frame atual
    int aguardando_ack;             // Flag indicando se está aguardando ACK
} EstadoConexao;

// Estrutura para armazenar endereço MAC descoberto
typedef struct {
    uint8_t mac[6];           // Endereço MAC
    int descoberto;           // 0 = não descoberto, 1 = descoberto
    time_t ultima_comunicacao; // Timestamp da última comunicação
} EnderecoMAC;

// Funções de rede
int rede_cria_socket(const char *interface);
void rede_envia_frame(int sock, const uint8_t *dest_mac, const char *interface, uint8_t tipo, uint8_t sequencia, uint8_t *dados, uint8_t tamanho);
int rede_recebe_frame(int sock, Frame *frame, int timeout_sec);
uint8_t calcular_checksum(const Frame *frame);

// Funções para controle de fluxo stop-and-wait
void rede_inicializar_estado(EstadoConexao *estado);
int rede_enviar_com_confirmacao(int sock, const uint8_t *dest_mac, const char *interface, uint8_t tipo, uint8_t *dados, uint8_t tamanho, EstadoConexao *estado);
int rede_processar_ack_nack(Frame *frame, EstadoConexao *estado);
int rede_retransmitir_ultimo_frame(int sock, const uint8_t *dest_mac, const char *interface, EstadoConexao *estado);
int rede_verificar_sequencia(uint8_t seq_recebida, uint8_t seq_esperada);

// Funções auxiliares para aritmética de sequência
int seq_depois_de(uint8_t a, uint8_t b);
uint8_t seq_incrementar(uint8_t seq);

// Funções para descoberta de MAC
int rede_obter_mac_local(const char *interface, uint8_t *mac);
void rede_inicializar_endereco_mac(EnderecoMAC *endereco);
int rede_enviar_anuncio_servidor(int sock, const char *interface);
int rede_enviar_descoberta_cliente(int sock, const char *interface);
int rede_processar_descoberta(Frame *frame, uint8_t *mac_origem, EnderecoMAC *endereco_destino, int modo_servidor);
int rede_verificar_mac_expirado(EnderecoMAC *endereco);

#endif // LIB_REDE_H

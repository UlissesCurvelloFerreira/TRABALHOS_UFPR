# Projeto: Autodetecção de MAC para Comunicação via Raw Socket

## Visão Geral

Este documento descreve a solução para eliminar a necessidade de configuração manual de endereços MAC entre cliente e servidor, permitindo que a comunicação aconteça apenas informando a interface de rede.

## Abordagem

Para eliminar a necessidade de configuração manual dos endereços MAC, implementaremos um mecanismo de descoberta automática baseado em broadcast e identificação de protocolo. A solução manterá o protocolo e formatações de envio existentes, modificando apenas a parte de descoberta de endereços.

## Mecanismo de Descoberta

### 1. Endereço de Broadcast

Utilizaremos o endereço MAC de broadcast (FF:FF:FF:FF:FF:FF) para enviar mensagens iniciais de descoberta. Este endereço especial faz com que o frame seja entregue a todos os dispositivos na rede local.

### 2. Mensagens de Anúncio e Descoberta

Adicionaremos dois novos tipos de mensagem ao protocolo:
- `TIPO_ANUNCIO_SERVIDOR` (16): Enviado pelo servidor para anunciar sua presença
- `TIPO_DESCOBERTA_CLIENTE` (17): Enviado pelo cliente para descobrir o servidor

### 3. Processo de Descoberta

#### Servidor:
1. Ao iniciar, o servidor obtém o MAC da sua interface de rede
2. Periodicamente (a cada 2 segundos), envia frames de anúncio para o endereço de broadcast
3. Quando recebe um frame de descoberta de um cliente, armazena o MAC do cliente
4. Após identificar um cliente, o servidor pode enviar frames diretamente para o MAC do cliente

#### Cliente:
1. Ao iniciar, o cliente obtém o MAC da sua interface de rede
2. Envia frames de descoberta para o endereço de broadcast
3. Aguarda receber um frame de anúncio do servidor
4. Quando recebe um anúncio, armazena o MAC do servidor
5. Após identificar o servidor, o cliente pode enviar frames diretamente para o MAC do servidor

### 4. Armazenamento de MACs Descobertos

Tanto cliente quanto servidor manterão uma estrutura para armazenar os MACs descobertos:

```c
typedef struct {
    uint8_t mac[6];
    int descoberto;  // 0 = não descoberto, 1 = descoberto
    time_t ultima_comunicacao;  // Timestamp da última comunicação
} EnderecoMAC;
```

## Modificações Necessárias

### 1. Biblioteca de Rede (libRede.h/c)

- Adicionar funções para obter o MAC da interface local
- Adicionar constante para o endereço MAC de broadcast
- Adicionar novos tipos de mensagem para descoberta
- Implementar funções para envio e processamento de mensagens de descoberta

### 2. Cliente (cliente.c)

- Remover configuração manual de MAC do servidor
- Implementar lógica de descoberta do servidor
- Modificar envio de frames para usar o MAC descoberto

### 3. Servidor (servidor.c)

- Remover configuração manual de MAC do cliente
- Implementar lógica de anúncio e descoberta de clientes
- Modificar envio de frames para usar o MAC descoberto

## Fluxo de Comunicação

1. **Fase de Descoberta**:
   - Servidor envia anúncios periódicos via broadcast
   - Cliente envia mensagens de descoberta via broadcast
   - Ambos armazenam os MACs quando recebem mensagens

2. **Fase de Comunicação**:
   - Após a descoberta, a comunicação continua normalmente usando os MACs descobertos
   - O protocolo stop-and-wait com timeout e retransmissão funciona como antes

3. **Reconexão**:
   - Se a comunicação for interrompida por um período prolongado, o processo de descoberta é reiniciado

## Vantagens da Solução

1. **Simplicidade para o Usuário**: Não é necessário configurar manualmente os endereços MAC
2. **Flexibilidade**: Funciona mesmo se os endereços MAC mudarem
3. **Robustez**: Suporta reconexão automática após falhas
4. **Compatibilidade**: Mantém o protocolo e formatações existentes

## Limitações

1. **Tráfego Adicional**: O uso de broadcast gera tráfego adicional na rede
2. **Segurança**: Qualquer dispositivo na rede pode interceptar as mensagens de descoberta
3. **Ambiente**: Funciona apenas em redes locais onde broadcast é permitido

## Conclusão

Esta solução elimina a necessidade de configuração manual de endereços MAC, mantendo a funcionalidade do protocolo existente. A implementação será feita nos arquivos V2, permitindo que os usuários escolham entre a versão original e a versão com autodetecção.

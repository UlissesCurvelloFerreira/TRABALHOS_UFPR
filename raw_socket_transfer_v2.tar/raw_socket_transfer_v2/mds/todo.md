- [X] Analisar enunciado, referências e arquivos existentes
  - [X] Revisar o enunciado do trabalho e requisitos
  - [X] Analisar os arquivos de código fornecidos (cliente.c, servidor.c, libRede.c/h)
  - [X] Estudar referências sobre aritmética de números de sequência
  - [X] Estudar referências sobre timeouts em raw sockets

- [X] Projetar solução para autodetecção de MAC e comunicação sem configuração manual
  - [X] Definir mecanismo de descoberta via broadcast
  - [X] Especificar novos tipos de mensagem para anúncio e descoberta
  - [X] Projetar estrutura para armazenar endereços MAC descobertos
  - [X] Documentar fluxo de descoberta e comunicação
  - [X] Criar projeto_autodeteccao_mac.md

- [X] Implementar autodetecção e uso dinâmico de MAC em cliente e servidor V2
  - [X] Estender libRede_v2.h com novas estruturas e funções
  - [X] Implementar funções de descoberta em libRede_v2.c
  - [X] Implementar servidor_v2.c com anúncio e descoberta de cliente
  - [X] Implementar cliente_v2.c com descoberta de servidor
  - [X] Criar Makefile para compilação dos arquivos V2

- [X] Validar transferência entre máquinas usando apenas interface
  - [X] Criar guia de teste detalhado (guia_teste_v2.md)
  - [X] Documentar procedimentos de teste de descoberta automática
  - [X] Documentar procedimentos de teste de desconexão/reconexão

- [X] Atualizar documentação e todo.md com novas instruções V2
  - [X] Atualizar todo.md com progresso atual
  - [X] Criar documentação técnica para versão V2
  - [X] Documentar diferenças entre versão original e V2

- [ ] Reportar e entregar arquivos V2 ao usuário
  - [ ] Organizar todos os arquivos V2 para entrega
  - [ ] Verificar se todos os arquivos necessários estão incluídos
  - [ ] Enviar arquivos com explicação clara sobre as implementações

# Implementação de Protocolo Stop-and-Wait com Autodetecção de MAC

## Visão Geral

Este documento descreve a implementação da versão V2 do protocolo stop-and-wait com suporte a timeout, retransmissão, recuperação após desconexão/reconexão e **autodetecção de MAC**. Esta versão elimina a necessidade de configuração manual dos endereços MAC entre cliente e servidor, permitindo que a comunicação ocorra apenas informando a interface de rede.

## Diferenças em Relação à Versão Original

A principal diferença desta versão V2 é a **eliminação da necessidade de configuração manual dos endereços MAC**. Na versão original, era necessário editar o código-fonte para inserir os endereços MAC corretos do cliente e servidor. Na versão V2, os endereços são descobertos automaticamente durante a execução.

### Principais Melhorias:

1. **Autodetecção de MAC**: Cliente e servidor descobrem automaticamente o endereço MAC um do outro
2. **Comunicação via Broadcast**: Uso de mensagens broadcast para anúncio e descoberta
3. **Recuperação de Conexão**: Redescoberta automática após desconexão prolongada
4. **Maior Robustez**: Funcionamento sem conhecimento prévio da topologia da rede

## Componentes Implementados

### 1. Biblioteca de Rede (`libRede_v2.h` e `libRede_v2.c`)

A biblioteca de rede foi estendida para incluir:

- **Endereço MAC de Broadcast**: Constante para o endereço FF:FF:FF:FF:FF:FF
- **Novos Tipos de Mensagem**: TIPO_ANUNCIO_SERVIDOR (16) e TIPO_DESCOBERTA_CLIENTE (17)
- **Estrutura de Endereço MAC**: Armazena MAC descoberto e timestamp da última comunicação
- **Funções de Descoberta**: Envio e processamento de mensagens de anúncio e descoberta
- **Verificação de Expiração**: Detecção de MACs expirados para forçar redescoberta

### 2. Servidor (`servidor_v2.c`)

O servidor foi modificado para:

- **Enviar Anúncios Periódicos**: Broadcast do MAC do servidor a cada 2 segundos
- **Processar Descobertas**: Identificação e armazenamento do MAC do cliente
- **Verificar Expiração**: Detecção de MAC expirado para forçar redescoberta
- **Eliminar Configuração Manual**: Remoção da necessidade de configurar o MAC do cliente

### 3. Cliente (`cliente_v2.c`)

O cliente foi modificado para:

- **Enviar Mensagens de Descoberta**: Broadcast para encontrar o servidor
- **Processar Anúncios**: Identificação e armazenamento do MAC do servidor
- **Verificar Expiração**: Detecção de MAC expirado para forçar redescoberta
- **Eliminar Configuração Manual**: Remoção da necessidade de configurar o MAC do servidor

## Fluxo de Descoberta e Comunicação

### Fase de Descoberta

1. **Inicialização do Servidor**:
   - Servidor obtém seu próprio MAC da interface
   - Servidor envia anúncios periódicos via broadcast
   - Servidor aguarda mensagens de descoberta de clientes

2. **Inicialização do Cliente**:
   - Cliente obtém seu próprio MAC da interface
   - Cliente envia mensagens de descoberta via broadcast
   - Cliente aguarda anúncios do servidor

3. **Descoberta Mútua**:
   - Quando o servidor recebe uma mensagem de descoberta, armazena o MAC do cliente
   - Quando o cliente recebe um anúncio, armazena o MAC do servidor
   - Ambos atualizam o timestamp da última comunicação

### Fase de Comunicação

Após a descoberta, a comunicação continua normalmente usando os MACs descobertos:

1. **Envio de Frames**:
   - Frames são enviados diretamente para o MAC descoberto
   - O protocolo stop-and-wait com timeout e retransmissão funciona como antes

2. **Verificação de Expiração**:
   - Periodicamente, verifica-se se o MAC descoberto expirou (sem comunicação por 60 segundos)
   - Se expirou, reinicia-se o processo de descoberta

3. **Reconexão Automática**:
   - Após uma desconexão prolongada, o processo de descoberta é reiniciado automaticamente
   - A transferência continua do ponto onde parou após a redescoberta

## Parâmetros de Descoberta

- **Intervalo de Anúncio/Descoberta**: 2 segundos
- **Tempo de Expiração de MAC**: 60 segundos
- **Máximo de Tentativas de Descoberta**: 30

## Como Usar

Para usar esta versão com autodetecção de MAC:

1. Compile os arquivos V2:
   ```
   make clean
   make
   ```

2. Execute o servidor em uma máquina:
   ```
   sudo ./servidor_v2 <interface>
   ```
   Substitua `<interface>` pelo nome da interface de rede (ex: eth0)

3. Execute o cliente em outra máquina:
   ```
   sudo ./cliente_v2 <interface>
   ```
   Substitua `<interface>` pelo nome da interface de rede

4. Observe as mensagens de descoberta e aguarde a comunicação ser estabelecida automaticamente

## Conclusão

Esta implementação V2 elimina a necessidade de configuração manual de endereços MAC, tornando o sistema mais fácil de usar e mais robusto. A autodetecção de MAC permite que a comunicação ocorra apenas informando a interface de rede, atendendo ao requisito de simplificação solicitado.

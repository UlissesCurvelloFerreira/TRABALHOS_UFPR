#ifndef LIB_TABULEIRO_H
#define LIB_TABULEIRO_H

#include <stdint.h>

#define GRID_SIZE 8

typedef struct {
    int x;
    int y;
} Coordenada;

typedef enum {
    TIPO_TEXTO,
    TIPO_IMAGEM,
    TIPO_VIDEO,
    TIPO_DESCONHECIDO
} TipoTesouro;

typedef struct {
    Coordenada pos;
    TipoTesouro tipo;
    char nome_arquivo[64]; // Nome do arquivo do tesouro (1.txt, 2.jpg, etc.)
    int encontrado; // 0 = não encontrado, 1 = encontrado
} Tesouro;

typedef struct {
    Coordenada jogador_pos;
    Tesouro tesouros[8]; // 8 tesouros no máximo
    char mapa[GRID_SIZE][GRID_SIZE]; // Representação visual do mapa
} Tabuleiro;

// Funções para manipulação do tabuleiro
void tabuleiro_inicializar(Tabuleiro *tabuleiro);
void tabuleiro_sortear_tesouros(Tabuleiro *tabuleiro);
void tabuleiro_atualizar_posicao_jogador(Tabuleiro *tabuleiro, Coordenada nova_pos);
int tabuleiro_verificar_tesouro(Tabuleiro *tabuleiro, Coordenada pos, Tesouro *tesouro_encontrado);
void tabuleiro_marcar_posicao_percorrida(Tabuleiro *tabuleiro, Coordenada pos);
void tabuleiro_marcar_tesouro_encontrado(Tabuleiro *tabuleiro, Coordenada pos);
void tabuleiro_imprimir(const Tabuleiro *tabuleiro);

#endif // LIB_TABULEIRO_H



# Guia de Teste: Transferência com Autodetecção de MAC

## Visão Geral

Este documento descreve como testar a versão V2 do sistema de transferência de arquivos, que implementa autodetecção de MAC, eliminando a necessidade de configuração manual dos endereços MAC entre cliente e servidor.

## Requisitos para Teste

1. Duas máquinas Linux conectadas diretamente por cabo de rede
2. Permissões de root (sudo) em ambas as máquinas
3. Interface de rede configurada em ambas as máquinas

## Preparação do Ambiente

1. Compile o código em ambas as máquinas:
   ```
   make clean
   make
   make setup
   ```

2. O comando `make setup` criará:
   - Diretório `tesouros_recebidos` para os arquivos recebidos pelo cliente
   - Diretório `objetos` com arquivos de teste (1.txt, 2.txt, 3.txt)

## Procedimento de Teste

### Iniciar os Programas

1. Na máquina servidor:
   ```
   sudo ./servidor_v2 <interface>
   ```
   Substitua `<interface>` pelo nome da interface de rede (ex: enp3s0, eth0)

2. Na máquina cliente:
   ```
   sudo ./cliente_v2 <interface>
   ```
   Substitua `<interface>` pelo nome da interface de rede

### Teste de Descoberta Automática

1. Observe as mensagens de log no servidor e cliente
2. O servidor enviará anúncios periódicos via broadcast
3. O cliente enviará mensagens de descoberta via broadcast
4. Verifique se o cliente descobre o servidor e vice-versa
5. Confirme que a comunicação é estabelecida sem configuração manual de MAC

### Teste de Transferência Básica

1. No cliente, use as teclas W/A/S/D para mover o jogador pelo tabuleiro
2. Quando um tesouro for encontrado, o servidor iniciará automaticamente a transferência do arquivo
3. Verifique se o arquivo é recebido corretamente no diretório `tesouros_recebidos`

### Teste de Desconexão/Reconexão

#### Método 1: Simulação via Comando

1. Durante uma transferência de arquivo, pressione 'D' (maiúsculo) no cliente ou 'd' no servidor para simular uma desconexão
2. Observe as mensagens indicando que a desconexão simulada está ativa
3. Aguarde alguns segundos (simulando o período de desconexão)
4. Pressione 'D' novamente para simular a reconexão
5. Observe se a transferência é retomada automaticamente do ponto onde parou
6. Verifique se o arquivo é recebido completamente e sem corrupção

#### Método 2: Desconexão Física

1. Durante uma transferência de arquivo, desconecte fisicamente o cabo de rede
2. Aguarde alguns segundos
3. Reconecte o cabo
4. Observe se a descoberta automática ocorre novamente
5. Verifique se a transferência é retomada automaticamente após a reconexão
6. Confirme se o arquivo é recebido completamente e sem corrupção

## Verificação de Resultados

1. Compare o tamanho e conteúdo dos arquivos originais com os recebidos
2. Verifique as mensagens de log para confirmar:
   - Descoberta automática de MAC
   - Detecção de timeout
   - Retransmissão de frames
   - Recuperação da sequência correta
   - Conclusão bem-sucedida da transferência

## Comandos Disponíveis

### Servidor
- `d` - Ativar/desativar simulação de desconexão
- `q` - Sair do programa
- `h` - Exibir ajuda

### Cliente
- `w/a/s/d` - Mover para cima/esquerda/baixo/direita
- `D` - Ativar/desativar simulação de desconexão
- `q` - Sair do programa
- `h` - Exibir ajuda

## Comportamento Esperado

1. **Durante Inicialização**:
   - Servidor envia anúncios periódicos
   - Cliente envia mensagens de descoberta
   - Ambos descobrem o MAC um do outro automaticamente

2. **Durante Operação Normal**:
   - Transferência fluida de arquivos
   - ACKs confirmando cada frame recebido
   - Progresso contínuo da transferência

3. **Durante Desconexão**:
   - Servidor detecta timeouts e inicia retransmissões
   - Backoff exponencial aumenta gradualmente o intervalo entre retransmissões
   - Mensagens de log indicam tentativas de retransmissão

4. **Após Reconexão**:
   - Redescoberta automática de MAC
   - Transferência é retomada automaticamente do último frame não confirmado
   - Cliente continua recebendo e processando frames a partir do ponto onde parou
   - Arquivo é completado sem corrupção ou perda de dados

## Resolução de Problemas

1. **Erro "Socket: Operation not permitted"**:
   - Verifique se está executando com permissões de root (sudo)

2. **Frames não são recebidos**:
   - Confirme que a interface de rede está correta e ativa
   - Verifique se o firewall não está bloqueando a comunicação

3. **Transferência não é retomada após reconexão**:
   - Verifique se o número máximo de retransmissões não foi excedido
   - Confirme que o timeout máximo não foi atingido
   - Reinicie cliente e servidor para forçar nova descoberta

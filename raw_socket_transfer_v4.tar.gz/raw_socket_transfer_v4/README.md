# README - Sistema de Transferência de Arquivos com Raw Sockets (V4)

Este projeto implementa um sistema de transferência de arquivos usando raw sockets com protocolo stop-and-wait, timeout, retransmissão e autodetecção de MAC.

## Versão V4 - Correções de Portabilidade Universal

Esta versão V4 corrige problemas de compilação relacionados à falta de inclusão de cabeçalhos necessários para as funções de socket, select e estruturas como fd_set, struct timeval e struct ifreq. Agora o código compila corretamente em qualquer distribuição Linux padrão.

## Principais Correções na V4

1. **Adicionados cabeçalhos necessários**:
   - `<net/if.h>` para `struct ifreq` e `IF_NAMESIZE`
   - `<sys/select.h>` para `fd_set` e função `select()`
   - `<sys/time.h>` para `struct timeval`
   - `<netinet/if_ether.h>` para `struct ether_header`

2. **Substituição de constantes**:
   - `IFNAMSIZ` substituído por `IF_NAMESIZE` para maior portabilidade

## Requisitos

- Duas máquinas Linux conectadas diretamente por cabo de rede
- Permissões de root (sudo) em ambas as máquinas
- GCC e Make instalados

## Arquivos do Projeto

### Biblioteca de Rede
- `libRede_v4.h` e `libRede_v4.c`: Implementação da comunicação via raw sockets com autodetecção de MAC

### Biblioteca de Tabuleiro
- `libTabuleiro.h` e `libTabuleiro.c`: Implementação do tabuleiro de jogo e tesouros

### Aplicações
- `servidor_v4.c`: Servidor que gerencia o tabuleiro e envia arquivos
- `cliente_v4.c`: Cliente que se move pelo tabuleiro e recebe arquivos

### Compilação e Execução
- `Makefile`: Regras para compilação e execução

## Compilação

1. Clone ou descompacte o repositório
2. Entre no diretório do projeto
3. Execute o comando make:

```bash
make clean
make
make setup
```

O comando `make setup` criará os diretórios necessários e alguns arquivos de teste.

## Execução

### Método 1: Execução direta

1. Na máquina servidor:
```bash
sudo ./servidor_v4 <interface>
```

2. Na máquina cliente:
```bash
sudo ./cliente_v4 <interface>
```

Substitua `<interface>` pelo nome da interface de rede (ex: eth0, enp3s0).

### Método 2: Usando o Makefile

1. Na máquina servidor:
```bash
sudo make run_server IFACE=<interface>
```

2. Na máquina cliente:
```bash
sudo make run_client IFACE=<interface>
```

## Uso do Sistema

### Comandos do Servidor
- `d` - Ativar/desativar simulação de desconexão
- `q` - Sair do programa
- `h` - Exibir ajuda

### Comandos do Cliente
- `w/a/s/d` - Mover para cima/esquerda/baixo/direita
- `D` - Ativar/desativar simulação de desconexão
- `q` - Sair do programa
- `h` - Exibir ajuda

## Fluxo de Operação

1. Inicie o servidor primeiro
2. Inicie o cliente
3. Aguarde a descoberta automática dos MACs
4. No cliente, use as teclas W/A/S/D para mover o jogador pelo tabuleiro
5. Quando um tesouro for encontrado, o servidor iniciará automaticamente a transferência do arquivo
6. Os arquivos recebidos serão salvos no diretório `tesouros_recebidos/` na máquina cliente

## Teste de Desconexão/Reconexão

Para testar a resiliência a desconexões:

1. Durante uma transferência de arquivo, pressione 'D' no cliente ou 'd' no servidor para simular uma desconexão, ou desconecte fisicamente o cabo
2. Aguarde alguns segundos
3. Pressione 'D' novamente ou reconecte o cabo
4. Observe se a transferência é retomada automaticamente

## Solução de Problemas

1. **Erro "Socket: Operation not permitted"**:
   - Verifique se está executando com permissões de root (sudo)

2. **Frames não são recebidos**:
   - Confirme que a interface de rede está correta e ativa
   - Verifique se o firewall não está bloqueando a comunicação

3. **Transferência não é retomada após reconexão**:
   - Verifique se o número máximo de retransmissões não foi excedido
   - Reinicie cliente e servidor para forçar nova descoberta

## Histórico de Versões

- **V4**: Correção de portabilidade universal para compilação em qualquer distribuição Linux
- **V3**: Correção inicial de includes para estruturas de socket e select
- **V2**: Implementação de autodetecção de MAC
- **V1**: Implementação básica de transferência com timeout e retransmissão

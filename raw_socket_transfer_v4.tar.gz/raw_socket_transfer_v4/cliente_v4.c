#include "libRede_v4.h"
#include "libTabuleiro.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/select.h>
#include <sys/time.h>
#include <fcntl.h>
#include <netinet/if_ether.h>
#include <net/ethernet.h>
#include <net/if.h>  /* Para struct ifreq e IF_NAMESIZE */

// Variáveis globais
Tabuleiro meu_tabuleiro;
EstadoConexao estado_conexao;
EnderecoMAC endereco_servidor;
int sock;
char *interface_global;
volatile int transferencia_em_andamento = 0;
volatile int desconexao_simulada = 0;
time_t ultima_descoberta = 0;

// Diretório para salvar os tesouros recebidos
#define DIR_TESOUROS "tesouros_recebidos"

// Estrutura para controlar a recepção de arquivos
typedef struct {
    FILE *arquivo;
    char nome[256];
    int tipo;
    long bytes_recebidos;
    int completo;
} ArquivoRecebido;

ArquivoRecebido arquivo_atual = {NULL, "", 0, 0, 0};

// Handler para sinal SIGUSR1 (usado para simular desconexão)
void simular_desconexao_handler(int signum) {
    desconexao_simulada = !desconexao_simulada;
    printf("\n[CLIENTE] %s desconexão simulada\n", 
           desconexao_simulada ? "Ativando" : "Desativando");
}

// Função para exibir o mapa no cliente
void cliente_exibe_mapa(const Tabuleiro *tabuleiro) {
    tabuleiro_imprimir(tabuleiro);
}

// Função para iniciar a recepção de um arquivo
int iniciar_recepcao_arquivo(const char *nome, int tipo) {
    // Cria o diretório de tesouros se não existir
    struct stat st = {0};
    if (stat(DIR_TESOUROS, &st) == -1) {
        mkdir(DIR_TESOUROS, 0755);
    }
    
    // Fecha arquivo anterior se estiver aberto
    if (arquivo_atual.arquivo) {
        fclose(arquivo_atual.arquivo);
        arquivo_atual.arquivo = NULL;
        
        // Se o arquivo anterior não foi completado, marca como incompleto
        if (!arquivo_atual.completo) {
            printf("[CLIENTE] Arquivo anterior não foi completado: %s\n", arquivo_atual.nome);
        }
    }
    
    // Prepara o novo arquivo
    char caminho_completo[512];
    snprintf(caminho_completo, sizeof(caminho_completo), "%s/%s", DIR_TESOUROS, nome);
    
    arquivo_atual.arquivo = fopen(caminho_completo, "wb");
    if (!arquivo_atual.arquivo) {
        perror("[CLIENTE] Erro ao criar arquivo para recepção");
        return 0;
    }
    
    strncpy(arquivo_atual.nome, nome, sizeof(arquivo_atual.nome) - 1);
    arquivo_atual.tipo = tipo;
    arquivo_atual.bytes_recebidos = 0;
    arquivo_atual.completo = 0;
    
    printf("[CLIENTE] Iniciando recepção do arquivo: %s (tipo %d)\n", nome, tipo);
    return 1;
}

// Função para adicionar dados ao arquivo em recepção
int adicionar_dados_arquivo(const uint8_t *dados, int tamanho) {
    if (!arquivo_atual.arquivo) {
        printf("[CLIENTE] Erro: Tentativa de adicionar dados sem arquivo aberto\n");
        return 0;
    }
    
    size_t escritos = fwrite(dados, 1, tamanho, arquivo_atual.arquivo);
    if (escritos != tamanho) {
        perror("[CLIENTE] Erro ao escrever dados no arquivo");
        return 0;
    }
    
    arquivo_atual.bytes_recebidos += tamanho;
    printf("[CLIENTE] Recebidos %d bytes, total %ld bytes\n", tamanho, arquivo_atual.bytes_recebidos);
    return 1;
}

// Função para finalizar a recepção do arquivo
int finalizar_recepcao_arquivo() {
    if (!arquivo_atual.arquivo) {
        printf("[CLIENTE] Erro: Tentativa de finalizar arquivo sem arquivo aberto\n");
        return 0;
    }
    
    fclose(arquivo_atual.arquivo);
    arquivo_atual.arquivo = NULL;
    arquivo_atual.completo = 1;
    
    printf("[CLIENTE] Arquivo recebido com sucesso: %s (%ld bytes)\n", 
           arquivo_atual.nome, arquivo_atual.bytes_recebidos);
    
    // Aqui poderia ser implementada a exibição do arquivo conforme seu tipo
    printf("[CLIENTE] Para visualizar o tesouro, abra o arquivo: %s/%s\n", 
           DIR_TESOUROS, arquivo_atual.nome);
    
    return 1;
}

// Função para processar frames recebidos do servidor
void cliente_processa_frame(Frame *frame, uint8_t *mac_origem) {
    uint8_t tipo = frame->sequencia_tipo & 0x0F;
    uint8_t seq = (frame->sequencia_tipo >> 3) & 0x1F;

    // Processa mensagens de anúncio do servidor
    if (tipo == TIPO_ANUNCIO_SERVIDOR) {
        if (rede_processar_descoberta(frame, mac_origem, &endereco_servidor, 0)) {
            // Servidor descoberto
            printf("[CLIENTE] Servidor descoberto!\n");
            return;
        }
    }
    
    // Se o servidor não foi descoberto, ignora outros tipos de mensagem
    if (!endereco_servidor.descoberto) {
        printf("[CLIENTE] Servidor não descoberto. Ignorando frame tipo %d.\n", tipo);
        return;
    }
    
    // Atualiza timestamp da última comunicação
    endereco_servidor.ultima_comunicacao = time(NULL);

    // Verifica se a sequência é a esperada
    if (seq == estado_conexao.ultima_seq_recebida) {
        // Frame duplicado, reenvia ACK
        printf("[CLIENTE] Frame duplicado (Seq: %d). Reenviando ACK.\n", seq);
        rede_envia_frame(sock, endereco_servidor.mac, interface_global, TIPO_ACK, seq, NULL, 0);
        return;
    }

    if (seq != seq_incrementar(estado_conexao.ultima_seq_recebida)) {
        printf("[CLIENTE] Sequência fora de ordem (Esperado: %d, Recebido: %d). Enviando NACK.\n", 
               seq_incrementar(estado_conexao.ultima_seq_recebida), seq);
        rede_envia_frame(sock, endereco_servidor.mac, interface_global, TIPO_NACK, estado_conexao.ultima_seq_recebida, NULL, 0);
        return;
    }

    // Atualiza a última sequência recebida
    estado_conexao.ultima_seq_recebida = seq;

    switch (tipo) {
        case TIPO_DADOS:
            // Receber dados de arquivo (tesouro)
            printf("[CLIENTE] Recebendo dados de tesouro...\n");
            if (transferencia_em_andamento) {
                adicionar_dados_arquivo(frame->dados, frame->tamanho);
            } else {
                printf("[CLIENTE] Erro: Recebendo dados sem transferência iniciada\n");
            }
            break;
            
        case TIPO_FIM_ARQUIVO:
            printf("[CLIENTE] Fim de arquivo de tesouro recebido.\n");
            if (transferencia_em_andamento) {
                finalizar_recepcao_arquivo();
                transferencia_em_andamento = 0;
            } else {
                printf("[CLIENTE] Erro: Recebendo fim de arquivo sem transferência iniciada\n");
            }
            break;
            
        case TIPO_TEXTO_ACK_NOME:
            printf("[CLIENTE] Tesouro de texto recebido: %s\n", frame->dados);
            transferencia_em_andamento = 1;
            iniciar_recepcao_arquivo((char*)frame->dados, TIPO_TEXTO);
            break;
            
        case TIPO_VIDEO_ACK_NOME:
            printf("[CLIENTE] Tesouro de vídeo recebido: %s\n", frame->dados);
            transferencia_em_andamento = 1;
            iniciar_recepcao_arquivo((char*)frame->dados, TIPO_VIDEO);
            break;
            
        case TIPO_IMAGEM_ACK_NOME:
            printf("[CLIENTE] Tesouro de imagem recebido: %s\n", frame->dados);
            transferencia_em_andamento = 1;
            iniciar_recepcao_arquivo((char*)frame->dados, TIPO_IMAGEM);
            break;
            
        case TIPO_OK_ACK:
            printf("[CLIENTE] OK + ACK recebido (Seq: %d).\n", seq);
            // Confirmação de movimento ou outra ação
            break;
            
        case TIPO_ERRO:
            printf("[CLIENTE] Erro recebido: %d\n", frame->dados[0]);
            break;
            
        case TIPO_ACK:
            printf("[CLIENTE] ACK recebido (Seq: %d).\n", seq);
            rede_processar_ack_nack(frame, &estado_conexao);
            break;
            
        case TIPO_NACK:
            printf("[CLIENTE] NACK recebido (Seq: %d).\n", seq);
            if (rede_processar_ack_nack(frame, &estado_conexao) < 0) {
                // Retransmite o último frame
                rede_retransmitir_ultimo_frame(sock, endereco_servidor.mac, interface_global, &estado_conexao);
            }
            break;
            
        default:
            printf("[CLIENTE] Tipo de frame desconhecido: %d\n", tipo);
            break;
    }
    
    // Envia ACK após processar o frame
    rede_envia_frame(sock, endereco_servidor.mac, interface_global, TIPO_ACK, seq, NULL, 0);
}

void exibir_ajuda() {
    printf("\n--- Comandos do Cliente ---\n");
    printf("w/a/s/d - Mover para cima/esquerda/baixo/direita\n");
    printf("D - Simular desconexão/reconexão\n");
    printf("q - Sair\n");
    printf("h - Exibir esta ajuda\n");
    printf("-------------------------\n\n");
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Uso: %s <interface>\n", argv[0]);
        return 1;
    }

    interface_global = argv[1];
    sock = rede_cria_socket(interface_global);
    if (sock < 0) {
        return 1;
    }

    // Configura o handler para simular desconexão
    signal(SIGUSR1, simular_desconexao_handler);

    // Inicializa o estado da conexão
    rede_inicializar_estado(&estado_conexao);
    
    // Inicializa a estrutura de endereço MAC do servidor
    rede_inicializar_endereco_mac(&endereco_servidor);

    // Inicializa o tabuleiro do cliente (apenas para exibição local)
    tabuleiro_inicializar(&meu_tabuleiro);
    cliente_exibe_mapa(&meu_tabuleiro);

    printf("[CLIENTE] Descobrindo servidor...\n");
    exibir_ajuda();
    
    // Envia descoberta inicial
    rede_enviar_descoberta_cliente(sock, interface_global);
    ultima_descoberta = time(NULL);

    char input;
    Coordenada nova_pos = meu_tabuleiro.jogador_pos;
    int tentativas_descoberta = 0;

    while (1) {
        // Tenta receber um frame do servidor (não bloqueante ou com timeout curto)
        Frame frame_recebido;
        uint8_t mac_origem[6];
        int ret = rede_recebe_frame(sock, &frame_recebido, 1); // Timeout de 1 segundo
        
        if (ret == 1) {
            // Se a desconexão simulada estiver ativa, ignora o frame
            if (desconexao_simulada) {
                printf("[CLIENTE] Frame recebido durante desconexão simulada, ignorando.\n");
                continue;
            }
            
            // Extrai o MAC de origem do frame recebido
            struct ether_header* eth = (struct ether_header*)(((uint8_t*)&frame_recebido) - sizeof(struct ether_header));
            memcpy(mac_origem, eth->ether_shost, 6);
            
            cliente_processa_frame(&frame_recebido, mac_origem);
        } else if (ret == -1) {
            perror("[CLIENTE] Erro ao receber frame");
        }

        // Verifica se é hora de enviar uma nova descoberta
        time_t agora = time(NULL);
        if (!endereco_servidor.descoberto && agora - ultima_descoberta >= DISCOVERY_INTERVAL) {
            if (tentativas_descoberta < MAX_DISCOVERY_ATTEMPTS) {
                printf("[CLIENTE] Enviando descoberta de servidor (%d/%d)...\n", 
                       tentativas_descoberta + 1, MAX_DISCOVERY_ATTEMPTS);
                rede_enviar_descoberta_cliente(sock, interface_global);
                ultima_descoberta = agora;
                tentativas_descoberta++;
            } else {
                printf("[CLIENTE] Máximo de tentativas de descoberta atingido. Tente novamente mais tarde.\n");
                // Reinicia contador para permitir novas tentativas
                tentativas_descoberta = 0;
                ultima_descoberta = agora;
            }
        }

        // Se estiver aguardando ACK e não estiver em desconexão simulada, verifica se precisa retransmitir
        if (estado_conexao.aguardando_ack && !desconexao_simulada && !transferencia_em_andamento && endereco_servidor.descoberto) {
            // Verifica se o timeout expirou
            if (estado_conexao.retransmissoes < MAX_RETRANSMISSOES) {
                rede_retransmitir_ultimo_frame(sock, endereco_servidor.mac, interface_global, &estado_conexao);
                estado_conexao.retransmissoes++;
                estado_conexao.timeout_atual = estado_conexao.timeout_atual * 2;
                if (estado_conexao.timeout_atual > TIMEOUT_MAXIMO) {
                    estado_conexao.timeout_atual = TIMEOUT_MAXIMO;
                }
            } else {
                printf("[CLIENTE] Máximo de retransmissões atingido. Desistindo.\n");
                estado_conexao.aguardando_ack = 0;
                estado_conexao.retransmissoes = 0;
                estado_conexao.timeout_atual = TIMEOUT_INICIAL;
            }
        }

        // Verifica se há entrada do usuário
        fd_set read_fds;
        struct timeval tv_input;
        FD_ZERO(&read_fds);
        FD_SET(STDIN_FILENO, &read_fds);
        tv_input.tv_sec = 0;
        tv_input.tv_usec = 100000; // 100ms

        if (select(STDIN_FILENO + 1, &read_fds, NULL, NULL, &tv_input) > 0) {
            scanf(" %c", &input);

            uint8_t tipo_movimento = 0;
            nova_pos = meu_tabuleiro.jogador_pos; // Reseta para a posição atual

            switch (input) {
                case 'w':
                    tipo_movimento = TIPO_DESLOCA_CIMA;
                    nova_pos.y++;
                    break;
                case 'a':
                    tipo_movimento = TIPO_DESLOCA_ESQUERDA;
                    nova_pos.x--;
                    break;
                case 's':
                    tipo_movimento = TIPO_DESLOCA_BAIXO;
                    nova_pos.y--;
                    break;
                case 'd':
                    tipo_movimento = TIPO_DESLOCA_DIREITA;
                    nova_pos.x++;
                    break;
                case 'D':
                    // Simula desconexão/reconexão
                    desconexao_simulada = !desconexao_simulada;
                    printf("[CLIENTE] %s desconexão simulada\n", 
                           desconexao_simulada ? "Ativando" : "Desativando");
                    break;
                case 'q':
                    printf("[CLIENTE] Saindo...\n");
                    close(sock);
                    return 0;
                case 'h':
                    exibir_ajuda();
                    break;
                default:
                    printf("[CLIENTE] Comando inválido.\n");
                    continue;
            }

            // Envia o frame de movimento apenas se for um movimento válido, não estiver em desconexão simulada
            // e o servidor tiver sido descoberto
            if (tipo_movimento != 0 && !desconexao_simulada && endereco_servidor.descoberto) {
                int resultado = rede_enviar_com_confirmacao(sock, endereco_servidor.mac, interface_global, 
                                                          tipo_movimento, NULL, 0, &estado_conexao);
                
                if (resultado > 0) {
                    // Atualiza a posição do jogador no tabuleiro local (para exibição imediata)
                    // A validação real da posição e tesouros será feita no servidor
                    tabuleiro_atualizar_posicao_jogador(&meu_tabuleiro, nova_pos);
                    cliente_exibe_mapa(&meu_tabuleiro);
                } else {
                    printf("[CLIENTE] Erro ao enviar movimento: %d\n", resultado);
                    
                    // Se o MAC do servidor expirou, reinicia a descoberta
                    if (rede_verificar_mac_expirado(&endereco_servidor)) {
                        printf("[CLIENTE] MAC do servidor expirou. Reiniciando descoberta...\n");
                        rede_enviar_descoberta_cliente(sock, interface_global);
                        ultima_descoberta = time(NULL);
                        tentativas_descoberta = 1;
                    }
                }
            } else if (tipo_movimento != 0 && !endereco_servidor.descoberto) {
                printf("[CLIENTE] Servidor não descoberto. Não é possível enviar movimento.\n");
                printf("[CLIENTE] Enviando nova descoberta...\n");
                rede_enviar_descoberta_cliente(sock, interface_global);
                ultima_descoberta = time(NULL);
                tentativas_descoberta++;
            }
        }
    }

    close(sock);
    return 0;
}

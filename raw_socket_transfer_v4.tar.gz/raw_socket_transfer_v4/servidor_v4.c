#include "libRede_v4.h"
#include "libTabuleiro.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <netinet/if_ether.h>
#include <net/ethernet.h>
#include <net/if.h>  /* Para struct ifreq e IF_NAMESIZE */

// Variáveis globais
Tabuleiro meu_tabuleiro;
EstadoConexao estado_conexao;
EnderecoMAC endereco_cliente;
int sock;
char *interface_global;
volatile int transferencia_em_andamento = 0;
volatile int desconexao_simulada = 0;
time_t ultimo_anuncio = 0;

// Função auxiliar para obter o tipo de tesouro pelo nome do arquivo
TipoTesouro obter_tipo_tesouro(const char *nome_arquivo) {
    const char *ext = strrchr(nome_arquivo, '.');
    if (ext) {
        if (strcmp(ext, ".txt") == 0) return TIPO_TEXTO;
        if (strcmp(ext, ".jpg") == 0 || strcmp(ext, ".png") == 0) return TIPO_IMAGEM;
        if (strcmp(ext, ".mp4") == 0) return TIPO_VIDEO;
    }
    return TIPO_DESCONHECIDO;
}

// Handler para sinal SIGUSR1 (usado para simular desconexão)
void simular_desconexao_handler(int signum) {
    desconexao_simulada = !desconexao_simulada;
    printf("\n[SERVIDOR] %s desconexão simulada\n", 
           desconexao_simulada ? "Ativando" : "Desativando");
}

// Função para enviar um arquivo (tesouro) para o cliente com suporte a desconexão/reconexão
void servidor_envia_tesouro(int sock, const char *interface, const char *caminho_arquivo, TipoTesouro tipo) {
    // Verifica se o cliente foi descoberto
    if (!endereco_cliente.descoberto) {
        printf("[SERVIDOR] Cliente não descoberto. Não é possível enviar tesouro.\n");
        return;
    }
    
    FILE *f = fopen(caminho_arquivo, "rb");
    if (!f) {
        perror("Erro ao abrir arquivo de tesouro");
        uint8_t erro_data = ERRO_SEM_PERMISSAO;
        rede_enviar_com_confirmacao(sock, endereco_cliente.mac, interface, TIPO_ERRO, &erro_data, 1, &estado_conexao);
        return;
    }

    transferencia_em_andamento = 1;
    
    // Envia o tipo de tesouro e nome do arquivo
    uint8_t tipo_msg_tesouro;
    switch (tipo) {
        case TIPO_TEXTO: tipo_msg_tesouro = TIPO_TEXTO_ACK_NOME; break;
        case TIPO_IMAGEM: tipo_msg_tesouro = TIPO_IMAGEM_ACK_NOME; break;
        case TIPO_VIDEO: tipo_msg_tesouro = TIPO_VIDEO_ACK_NOME; break;
        default: tipo_msg_tesouro = TIPO_DADOS; break; // Fallback
    }
    const char *nome_arquivo_apenas = strrchr(caminho_arquivo, '/');
    if (nome_arquivo_apenas) nome_arquivo_apenas++;
    else nome_arquivo_apenas = caminho_arquivo;

    printf("[SERVIDOR] Iniciando envio do arquivo: %s (tipo %d)\n", nome_arquivo_apenas, tipo_msg_tesouro);
    
    // Envia o nome do arquivo com confirmação
    int resultado = rede_enviar_com_confirmacao(sock, endereco_cliente.mac, interface, tipo_msg_tesouro, 
                                              (uint8_t*)nome_arquivo_apenas, strlen(nome_arquivo_apenas), 
                                              &estado_conexao);
    
    if (resultado <= 0) {
        printf("[SERVIDOR] Falha ao enviar nome do arquivo: %d\n", resultado);
        fclose(f);
        transferencia_em_andamento = 0;
        return;
    }

    // Posição atual no arquivo
    long posicao_arquivo = 0;
    
    // Envia os dados do arquivo em blocos
    uint8_t buffer_dados[MAX_PAYLOAD_SIZE];
    int lidos;
    int erro_fatal = 0;
    
    // Posiciona o arquivo no início
    fseek(f, 0, SEEK_SET);
    
    while (!erro_fatal && (lidos = fread(buffer_dados, 1, MAX_PAYLOAD_SIZE, f)) > 0) {
        // Verifica se a desconexão simulada está ativa
        if (desconexao_simulada) {
            printf("[SERVIDOR] Desconexão simulada ativa, aguardando reconexão...\n");
            while (desconexao_simulada) {
                sleep(1); // Aguarda até que a desconexão simulada seja desativada
            }
            printf("[SERVIDOR] Reconexão detectada, continuando transferência...\n");
        }
        
        // Verifica se o MAC do cliente expirou
        if (rede_verificar_mac_expirado(&endereco_cliente)) {
            printf("[SERVIDOR] MAC do cliente expirou. Aguardando redescoberta...\n");
            fclose(f);
            transferencia_em_andamento = 0;
            return;
        }
        
        resultado = rede_enviar_com_confirmacao(sock, endereco_cliente.mac, interface, TIPO_DADOS, 
                                              buffer_dados, lidos, &estado_conexao);
        
        if (resultado <= 0) {
            if (resultado == -ERRO_MAX_RETRANSMISSOES) {
                printf("[SERVIDOR] Máximo de retransmissões atingido. Abortando transferência.\n");
                erro_fatal = 1;
                break;
            } else if (resultado == -ERRO_TIMEOUT) {
                printf("[SERVIDOR] Timeout global excedido. Abortando transferência.\n");
                erro_fatal = 1;
                break;
            } else {
                printf("[SERVIDOR] Erro ao enviar dados: %d. Tentando continuar...\n", resultado);
                // Tenta continuar a transferência
            }
        } else {
            // Atualiza a posição no arquivo
            posicao_arquivo += lidos;
            printf("[SERVIDOR] Enviados %d bytes, total %ld bytes\n", lidos, posicao_arquivo);
        }
    }
    
    if (!erro_fatal) {
        // Envia frame de fim de arquivo
        resultado = rede_enviar_com_confirmacao(sock, endereco_cliente.mac, interface, TIPO_FIM_ARQUIVO, 
                                              NULL, 0, &estado_conexao);
        
        if (resultado <= 0) {
            printf("[SERVIDOR] Erro ao enviar fim de arquivo: %d\n", resultado);
        } else {
            printf("[SERVIDOR] Arquivo enviado com sucesso: %s (%ld bytes)\n", 
                   nome_arquivo_apenas, posicao_arquivo);
        }
    }
    
    fclose(f);
    transferencia_em_andamento = 0;
}

// Função para processar frames recebidos do cliente
void servidor_processa_frame(int sock, const char *interface, Frame *frame, uint8_t *mac_origem) {
    uint8_t tipo = frame->sequencia_tipo & 0x0F;
    uint8_t seq = (frame->sequencia_tipo >> 3) & 0x1F;

    // Processa mensagens de descoberta
    if (tipo == TIPO_DESCOBERTA_CLIENTE) {
        if (rede_processar_descoberta(frame, mac_origem, &endereco_cliente, 1)) {
            // Cliente descoberto, envia anúncio de resposta
            rede_enviar_anuncio_servidor(sock, interface);
            ultimo_anuncio = time(NULL);
            return;
        }
    }
    
    // Se o cliente não foi descoberto, ignora outros tipos de mensagem
    if (!endereco_cliente.descoberto) {
        printf("[SERVIDOR] Cliente não descoberto. Ignorando frame tipo %d.\n", tipo);
        return;
    }
    
    // Atualiza timestamp da última comunicação
    endereco_cliente.ultima_comunicacao = time(NULL);

    // Verifica se a sequência é a esperada
    if (seq == estado_conexao.ultima_seq_recebida) {
        // Frame duplicado, reenvia ACK
        printf("[SERVIDOR] Frame duplicado (Seq: %d). Reenviando ACK.\n", seq);
        rede_envia_frame(sock, endereco_cliente.mac, interface, TIPO_ACK, seq, NULL, 0);
        return;
    }

    if (seq != seq_incrementar(estado_conexao.ultima_seq_recebida)) {
        printf("[SERVIDOR] Sequência fora de ordem (Esperado: %d, Recebido: %d). Enviando NACK.\n", 
               seq_incrementar(estado_conexao.ultima_seq_recebida), seq);
        rede_envia_frame(sock, endereco_cliente.mac, interface, TIPO_NACK, estado_conexao.ultima_seq_recebida, NULL, 0);
        return;
    }

    // Atualiza a última sequência recebida
    estado_conexao.ultima_seq_recebida = seq;

    Coordenada nova_pos = meu_tabuleiro.jogador_pos;
    int movimento_valido = 0;

    switch (tipo) {
        case TIPO_DESLOCA_DIREITA:
            nova_pos.x++;
            movimento_valido = 1;
            break;
        case TIPO_DESLOCA_CIMA:
            nova_pos.y++;
            movimento_valido = 1;
            break;
        case TIPO_DESLOCA_BAIXO:
            nova_pos.y--;
            movimento_valido = 1;
            break;
        case TIPO_DESLOCA_ESQUERDA:
            nova_pos.x--;
            movimento_valido = 1;
            break;
        case TIPO_ACK:
            printf("[SERVIDOR] ACK recebido do cliente (Seq: %d).\n", seq);
            rede_processar_ack_nack(frame, &estado_conexao);
            break;
        case TIPO_NACK:
            printf("[SERVIDOR] NACK recebido do cliente (Seq: %d).\n", seq);
            if (rede_processar_ack_nack(frame, &estado_conexao) < 0) {
                // Retransmite o último frame
                rede_retransmitir_ultimo_frame(sock, endereco_cliente.mac, interface, &estado_conexao);
            }
            break;
        default:
            printf("[SERVIDOR] Tipo de frame desconhecido: %d\n", tipo);
            break;
    }

    if (movimento_valido) {
        // Verifica limites do tabuleiro
        if (nova_pos.x >= 0 && nova_pos.x < GRID_SIZE &&
            nova_pos.y >= 0 && nova_pos.y < GRID_SIZE) {
            
            tabuleiro_atualizar_posicao_jogador(&meu_tabuleiro, nova_pos);
            tabuleiro_imprimir(&meu_tabuleiro);

            Tesouro tesouro_encontrado;
            if (tabuleiro_verificar_tesouro(&meu_tabuleiro, meu_tabuleiro.jogador_pos, &tesouro_encontrado)) {
                printf("Tesouro encontrado na posição (%d, %d)!\n", meu_tabuleiro.jogador_pos.x, meu_tabuleiro.jogador_pos.y);
                tabuleiro_marcar_tesouro_encontrado(&meu_tabuleiro, meu_tabuleiro.jogador_pos);
                
                // Determinar o nome do arquivo do tesouro (1.txt, 2.jpg, etc.)
                char caminho_tesouro[256];
                snprintf(caminho_tesouro, sizeof(caminho_tesouro), "objetos/%d.%s", 
                         (int)(rand() % 8) + 1, // Simula o nome do arquivo do tesouro (1 a 8)
                         (tesouro_encontrado.tipo == TIPO_TEXTO) ? "txt" : 
                         (tesouro_encontrado.tipo == TIPO_IMAGEM) ? "jpg" : 
                         (tesouro_encontrado.tipo == TIPO_VIDEO) ? "mp4" : "");

                // Para o protótipo, vamos sortear um tipo de tesouro para o arquivo
                TipoTesouro tipo_sorteado;
                int r = rand() % 3;
                if (r == 0) tipo_sorteado = TIPO_TEXTO;
                else if (r == 1) tipo_sorteado = TIPO_IMAGEM;
                else tipo_sorteado = TIPO_VIDEO;

                servidor_envia_tesouro(sock, interface, caminho_tesouro, tipo_sorteado);
            }
            
            // Envia confirmação de movimento válido
            rede_enviar_com_confirmacao(sock, endereco_cliente.mac, interface, TIPO_OK_ACK, NULL, 0, &estado_conexao);
        } else {
            printf("Movimento inválido: fora dos limites do tabuleiro.\n");
            uint8_t erro_data = 0; // Erro genérico
            rede_enviar_com_confirmacao(sock, endereco_cliente.mac, interface, TIPO_ERRO, &erro_data, 1, &estado_conexao);
        }
    }
    
    // Envia ACK para o frame recebido
    rede_envia_frame(sock, endereco_cliente.mac, interface, TIPO_ACK, seq, NULL, 0);
}

void exibir_ajuda() {
    printf("\n--- Comandos do Servidor ---\n");
    printf("d - Simular desconexão/reconexão\n");
    printf("q - Sair\n");
    printf("h - Exibir esta ajuda\n");
    printf("-------------------------\n\n");
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Uso: %s <interface>\n", argv[0]);
        return 1;
    }

    interface_global = argv[1];
    sock = rede_cria_socket(interface_global);
    if (sock < 0) {
        return 1;
    }

    // Configura o handler para simular desconexão
    signal(SIGUSR1, simular_desconexao_handler);

    // Inicializa o estado da conexão
    rede_inicializar_estado(&estado_conexao);
    
    // Inicializa a estrutura de endereço MAC do cliente
    rede_inicializar_endereco_mac(&endereco_cliente);

    // Inicializa o tabuleiro e sorteia os tesouros
    tabuleiro_inicializar(&meu_tabuleiro);
    tabuleiro_sortear_tesouros(&meu_tabuleiro);
    tabuleiro_imprimir(&meu_tabuleiro);

    printf("[SERVIDOR] Aguardando descoberta do cliente...\n");
    exibir_ajuda();
    
    // Envia anúncio inicial
    rede_enviar_anuncio_servidor(sock, interface_global);
    ultimo_anuncio = time(NULL);

    // Configura entrada não bloqueante para comandos do usuário
    fd_set read_fds;
    struct timeval tv;

    while (1) {
        // Verifica se há entrada do usuário
        FD_ZERO(&read_fds);
        FD_SET(STDIN_FILENO, &read_fds);
        tv.tv_sec = 0;
        tv.tv_usec = 100000; // 100ms

        if (select(STDIN_FILENO + 1, &read_fds, NULL, NULL, &tv) > 0) {
            char cmd;
            scanf(" %c", &cmd);
            
            switch (cmd) {
                case 'd':
                    // Simula desconexão/reconexão
                    desconexao_simulada = !desconexao_simulada;
                    printf("[SERVIDOR] %s desconexão simulada\n", 
                           desconexao_simulada ? "Ativando" : "Desativando");
                    break;
                case 'q':
                    printf("[SERVIDOR] Encerrando...\n");
                    close(sock);
                    return 0;
                case 'h':
                    exibir_ajuda();
                    break;
                default:
                    printf("[SERVIDOR] Comando desconhecido: %c\n", cmd);
                    break;
            }
        }

        // Verifica se é hora de enviar um novo anúncio
        time_t agora = time(NULL);
        if (agora - ultimo_anuncio >= DISCOVERY_INTERVAL) {
            rede_enviar_anuncio_servidor(sock, interface_global);
            ultimo_anuncio = agora;
        }

        // Tenta receber um frame
        Frame frame_recebido;
        uint8_t mac_origem[6];
        int ret = rede_recebe_frame(sock, &frame_recebido, 1); // Timeout de 1 segundo
        
        if (ret == 1) {
            // Se a desconexão simulada estiver ativa, ignora o frame
            if (desconexao_simulada) {
                printf("[SERVIDOR] Frame recebido durante desconexão simulada, ignorando.\n");
                continue;
            }
            
            // Extrai o MAC de origem do frame recebido
            struct ether_header* eth = (struct ether_header*)(((uint8_t*)&frame_recebido) - sizeof(struct ether_header));
            memcpy(mac_origem, eth->ether_shost, 6);
            
            servidor_processa_frame(sock, interface_global, &frame_recebido, mac_origem);
        } else if (ret == -1) {
            perror("[SERVIDOR] Erro ao receber frame");
        }
        
        // Se estiver aguardando ACK e não estiver em desconexão simulada, verifica se precisa retransmitir
        if (estado_conexao.aguardando_ack && !desconexao_simulada && !transferencia_em_andamento && endereco_cliente.descoberto) {
            // Verifica se o timeout expirou
            if (estado_conexao.retransmissoes < MAX_RETRANSMISSOES) {
                rede_retransmitir_ultimo_frame(sock, endereco_cliente.mac, interface_global, &estado_conexao);
                estado_conexao.retransmissoes++;
                estado_conexao.timeout_atual = estado_conexao.timeout_atual * 2;
                if (estado_conexao.timeout_atual > TIMEOUT_MAXIMO) {
                    estado_conexao.timeout_atual = TIMEOUT_MAXIMO;
                }
            } else {
                printf("[SERVIDOR] Máximo de retransmissões atingido. Desistindo.\n");
                estado_conexao.aguardando_ack = 0;
                estado_conexao.retransmissoes = 0;
                estado_conexao.timeout_atual = TIMEOUT_INICIAL;
            }
        }
    }

    close(sock);
    return 0;
}

#include "libTabuleiro.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

// Função para inicializar o tabuleiro
void tabuleiro_inicializar(Tabuleiro *tabuleiro) {
    for (int i = 0; i < GRID_SIZE; ++i) {
        for (int j = 0; j < GRID_SIZE; ++j) {
            tabuleiro->mapa[i][j] = '.'; // Posição vazia
        }
    }
    tabuleiro->jogador_pos.x = 0;
    tabuleiro->jogador_pos.y = 0;
    tabuleiro->mapa[tabuleiro->jogador_pos.y][tabuleiro->jogador_pos.x] = '@'; // Posição inicial do jogador

    for (int i = 0; i < 8; ++i) {
        tabuleiro->tesouros[i].encontrado = 0;
        tabuleiro->tesouros[i].tipo = TIPO_DESCONHECIDO;
        memset(tabuleiro->tesouros[i].nome_arquivo, 0, sizeof(tabuleiro->tesouros[i].nome_arquivo));
    }
}

// Função para sortear a posição dos tesouros
void tabuleiro_sortear_tesouros(Tabuleiro *tabuleiro) {
    srand(time(NULL));
    for (int i = 0; i < 8; ++i) {
        Coordenada nova_pos;
        int pos_ocupada;
        do {
            pos_ocupada = 0;
            nova_pos.x = rand() % GRID_SIZE;
            nova_pos.y = rand() % GRID_SIZE;

            // Verifica se a posição já está ocupada por outro tesouro
            for (int j = 0; j < i; ++j) {
                if (tabuleiro->tesouros[j].pos.x == nova_pos.x && tabuleiro->tesouros[j].pos.y == nova_pos.y) {
                    pos_ocupada = 1;
                    break;
                }
            }
            // Evita que o tesouro seja sorteado na posição inicial do jogador
            if (nova_pos.x == tabuleiro->jogador_pos.x && nova_pos.y == tabuleiro->jogador_pos.y) {
                pos_ocupada = 1;
            }
        } while (pos_ocupada);

        tabuleiro->tesouros[i].pos = nova_pos;
        // O tipo e nome do arquivo serão definidos quando o tesouro for encontrado
    }
}

void tabuleiro_atualizar_posicao_jogador(Tabuleiro *tabuleiro, Coordenada nova_pos) {
    // Verifica se a nova posição está dentro dos limites do grid
    if (nova_pos.x >= 0 && nova_pos.x < GRID_SIZE &&
        nova_pos.y >= 0 && nova_pos.y < GRID_SIZE) {
        
        // Marca a posição anterior do jogador como percorrida
        tabuleiro->mapa[tabuleiro->jogador_pos.y][tabuleiro->jogador_pos.x] = 'x';

        tabuleiro->jogador_pos = nova_pos;
        tabuleiro->mapa[tabuleiro->jogador_pos.y][tabuleiro->jogador_pos.x] = '@'; // Atualiza a posição do jogador
    } else {
        printf("Movimento inválido: fora dos limites do tabuleiro.\n");
    }
}

// Função para verificar se há um tesouro na posição atual do jogador
int tabuleiro_verificar_tesouro(Tabuleiro *tabuleiro, Coordenada pos, Tesouro *tesouro_encontrado) {
    for (int i = 0; i < 8; ++i) {
        if (tabuleiro->tesouros[i].pos.x == pos.x && tabuleiro->tesouros[i].pos.y == pos.y && !tabuleiro->tesouros[i].encontrado) {
            *tesouro_encontrado = tabuleiro->tesouros[i];
            return 1; // Tesouro encontrado
        }
    }
    return 0; // Nenhum tesouro encontrado
}

// Função para marcar uma posição como percorrida
void tabuleiro_marcar_posicao_percorrida(Tabuleiro *tabuleiro, Coordenada pos) {
    if (tabuleiro->mapa[pos.y][pos.x] == '.') {
        tabuleiro->mapa[pos.y][pos.x] = 'x';
    }
}

// Função para marcar um tesouro como encontrado
void tabuleiro_marcar_tesouro_encontrado(Tabuleiro *tabuleiro, Coordenada pos) {
    for (int i = 0; i < 8; ++i) {
        if (tabuleiro->tesouros[i].pos.x == pos.x && tabuleiro->tesouros[i].pos.y == pos.y) {
            tabuleiro->tesouros[i].encontrado = 1;
            tabuleiro->mapa[pos.y][pos.x] = 'T'; // Marca a posição do tesouro como 'T'
            break;
        }
    }
}

// Função para imprimir o tabuleiro
void tabuleiro_imprimir(const Tabuleiro *tabuleiro) {
    printf("\nTabuleiro:\n");
    for (int i = GRID_SIZE - 1; i >= 0; --i) { // Imprime de cima para baixo (y decrescente)
        for (int j = 0; j < GRID_SIZE; ++j) {
            printf("%c ", tabuleiro->mapa[i][j]);
        }
        printf("\n");
    }
    printf("Posição do Jogador: (%d, %d)\n", tabuleiro->jogador_pos.x, tabuleiro->jogador_pos.y);
    printf("Legenda: @ = Jogador, . = Vazio, x = Percorrido, T = Tesouro Encontrado\n");
}



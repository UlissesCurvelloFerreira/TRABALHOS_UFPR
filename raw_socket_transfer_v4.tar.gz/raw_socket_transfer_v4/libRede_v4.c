#define _DEFAULT_SOURCE
#include "libRede_v4.h"
#include <arpa/inet.h>
#include <linux/if_packet.h>
#include <net/ethernet.h>
#include <net/if.h>
#include <netinet/ether.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>

// Endereço MAC de broadcast
const uint8_t MAC_BROADCAST[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

// Função para criar um socket raw
int rede_cria_socket(const char *interface) {
    int s = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));
    if (s < 0) {
        perror("Socket");
        return -1;
    }

    struct sockaddr_ll addr = {0};
    addr.sll_family = AF_PACKET;
    addr.sll_protocol = htons(ETH_P_ALL);
    addr.sll_ifindex = if_nametoindex(interface);
    if (addr.sll_ifindex == 0) {
        perror("[ERRO] Interface inválida");
        close(s);
        return -1;
    }

    if (bind(s, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("Bind");
        close(s);
        return -1;
    }

    printf("[SOCKET] Vinculado à interface %s (index %d)\n", interface, addr.sll_ifindex);
    return s;
}

// Função para obter o MAC da interface local
int rede_obter_mac_local(const char *interface, uint8_t *mac) {
    struct ifreq ifr;
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    
    if (sock < 0) {
        perror("Socket para obter MAC");
        return -1;
    }
    
    strncpy(ifr.ifr_name, interface, IF_NAMESIZE - 1);
    
    if (ioctl(sock, SIOCGIFHWADDR, &ifr) < 0) {
        perror("ioctl SIOCGIFHWADDR");
        close(sock);
        return -1;
    }
    
    memcpy(mac, ifr.ifr_hwaddr.sa_data, 6);
    close(sock);
    
    printf("[MAC] Interface %s: %02x:%02x:%02x:%02x:%02x:%02x\n", 
           interface, mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    
    return 0;
}

// Função para calcular o checksum de um frame
uint8_t calcular_checksum(const Frame *frame) {
    uint8_t checksum = frame->tamanho + frame->sequencia_tipo;
    for (int i = 0; i < frame->tamanho; ++i) {
        checksum += frame->dados[i];
    }
    return checksum;
}

// Função para enviar um frame
void rede_envia_frame(int sock, const uint8_t *dest_mac, const char *interface, uint8_t tipo, uint8_t sequencia, uint8_t *dados, uint8_t tamanho) {
    uint8_t buffer[sizeof(struct ether_header) + sizeof(Frame)];
    struct ether_header *eth = (struct ether_header *)buffer;
    struct ifreq ifr;

    strncpy(ifr.ifr_name, interface, IF_NAMESIZE - 1);
    if (ioctl(sock, SIOCGIFHWADDR, &ifr) < 0) {
        perror("ioctl SIOCGIFHWADDR");
        return;
    }
    memcpy(eth->ether_shost, ifr.ifr_hwaddr.sa_data, 6);
    memcpy(eth->ether_dhost, dest_mac, 6);
    eth->ether_type = htons(PROTOCOLO_CUSTOM);

    Frame *frame = (Frame *)(buffer + sizeof(struct ether_header));
    frame->marcador_inicio = MARCADOR_INICIO;
    frame->tamanho = tamanho & 0x7F;
    frame->sequencia_tipo = ((sequencia & 0x1F) << 3) | (tipo & 0x0F);
    if (dados && tamanho > 0) {
        memcpy(frame->dados, dados, tamanho);
    }
    frame->checksum = calcular_checksum(frame);

    int enviado = send(sock, buffer, sizeof(struct ether_header) + 4 + tamanho, 0);
    if (enviado > 0) {
        printf("[SENDER] Frame enviado - Tipo: %d | Seq: %d | Tamanho: %d bytes | Destino: %02x:%02x:%02x:%02x:%02x:%02x\n", 
               tipo, sequencia, tamanho, dest_mac[0], dest_mac[1], dest_mac[2], dest_mac[3], dest_mac[4], dest_mac[5]);
    } else {
        perror("[SENDER] Erro ao enviar frame");
    }
}

// Função para receber um frame com timeout
int rede_recebe_frame(int sock, Frame *frame, int timeout_sec) {
    uint8_t buffer[sizeof(struct ether_header) + sizeof(Frame)];
    struct timeval tv;
    tv.tv_sec = timeout_sec;
    tv.tv_usec = 0;

    if (setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof(tv)) < 0) {
        perror("setsockopt SO_RCVTIMEO");
        return -1;
    }

    while (1) {
        int len = recv(sock, buffer, sizeof(buffer), 0);
        if (len < 0) {
            if (errno == EWOULDBLOCK || errno == EAGAIN) {
                printf("[RECEIVER] Timeout ao receber frame.\n");
                return 0; // Timeout
            }
            perror("[RECEIVER] Erro ao receber frame");
            return -1; // Erro
        }
        if (len == 0) continue; // Nenhum dado recebido

        struct ether_header* eth = (struct ether_header*) buffer;
        if (ntohs(eth->ether_type) != PROTOCOLO_CUSTOM) {
            // Protocolo diferente, ignorar silenciosamente
            continue;
        }

        Frame *received_frame = (Frame *)(buffer + sizeof(struct ether_header));

        if (received_frame->marcador_inicio != MARCADOR_INICIO) {
            // Sem marcador de início, ignorar silenciosamente
            continue;
        }

        // Copia os dados do frame recebido para a estrutura passada como parâmetro
        memcpy(frame, received_frame, sizeof(Frame));

        // Verifica o checksum
        uint8_t calculated_checksum = calcular_checksum(frame);
        if (calculated_checksum != frame->checksum) {
            printf("[RECEIVER] Checksum incorreto - Ignorado. Calculado: 0x%02x, Recebido: 0x%02x\n", calculated_checksum, frame->checksum);
            continue;
        }

        uint8_t tipo = frame->sequencia_tipo & 0x0F;
        uint8_t seq = (frame->sequencia_tipo >> 3) & 0x1F;
        printf("[RECEIVER] Frame recebido - Tipo: %d | Seq: %d | Tamanho: %d bytes | Origem: %02x:%02x:%02x:%02x:%02x:%02x\n", 
               tipo, seq, frame->tamanho, eth->ether_shost[0], eth->ether_shost[1], eth->ether_shost[2], 
               eth->ether_shost[3], eth->ether_shost[4], eth->ether_shost[5]);
        
        // Copia o MAC de origem para uso posterior
        memcpy(eth->ether_dhost, eth->ether_shost, 6);
        
        return 1; // Frame válido recebido
    }
}

// Funções para aritmética de sequência
int seq_depois_de(uint8_t a, uint8_t b) {
    // Verifica se a sequência 'a' vem depois da sequência 'b'
    // usando aritmética de números seriais
    return (((a - b) & SEQ_NUM_MAX) < (SEQ_NUM_MAX / 2));
}

uint8_t seq_incrementar(uint8_t seq) {
    return (seq + 1) & SEQ_NUM_MAX;
}

// Inicializa o estado da conexão
void rede_inicializar_estado(EstadoConexao *estado) {
    estado->ultima_seq_enviada = 0;
    estado->ultima_seq_confirmada = 0;
    estado->proxima_seq_envio = 0;
    estado->ultima_seq_recebida = SEQ_NUM_MAX; // Inicializa com o valor máximo para que o primeiro frame esperado seja 0
    estado->ultima_tipo_enviado = 0;
    estado->ultimo_tamanho_enviado = 0;
    memset(estado->dados_ultimo_frame, 0, MAX_PAYLOAD_SIZE);
    estado->timeout_atual = TIMEOUT_INICIAL;
    estado->retransmissoes = 0;
    estado->aguardando_ack = 0;
}

// Inicializa a estrutura de endereço MAC
void rede_inicializar_endereco_mac(EnderecoMAC *endereco) {
    memset(endereco->mac, 0, 6);
    endereco->descoberto = 0;
    endereco->ultima_comunicacao = 0;
}

// Verifica se o MAC expirou (não recebeu comunicação recente)
int rede_verificar_mac_expirado(EnderecoMAC *endereco) {
    if (!endereco->descoberto) {
        return 1; // Se não foi descoberto, considera expirado
    }
    
    time_t agora = time(NULL);
    if (agora - endereco->ultima_comunicacao > MAC_EXPIRY_TIME) {
        printf("[MAC] Endereço MAC expirado: %02x:%02x:%02x:%02x:%02x:%02x\n",
               endereco->mac[0], endereco->mac[1], endereco->mac[2],
               endereco->mac[3], endereco->mac[4], endereco->mac[5]);
        endereco->descoberto = 0;
        return 1;
    }
    
    return 0;
}

// Envia anúncio do servidor (broadcast)
int rede_enviar_anuncio_servidor(int sock, const char *interface) {
    uint8_t dados[6]; // Dados do anúncio (MAC do servidor)
    
    // Obtém o MAC local para incluir no anúncio
    if (rede_obter_mac_local(interface, dados) < 0) {
        return -1;
    }
    
    // Envia o anúncio para o endereço de broadcast
    rede_envia_frame(sock, MAC_BROADCAST, interface, TIPO_ANUNCIO_SERVIDOR, 0, dados, 6);
    
    return 0;
}

// Envia descoberta do cliente (broadcast)
int rede_enviar_descoberta_cliente(int sock, const char *interface) {
    uint8_t dados[6]; // Dados da descoberta (MAC do cliente)
    
    // Obtém o MAC local para incluir na descoberta
    if (rede_obter_mac_local(interface, dados) < 0) {
        return -1;
    }
    
    // Envia a descoberta para o endereço de broadcast
    rede_envia_frame(sock, MAC_BROADCAST, interface, TIPO_DESCOBERTA_CLIENTE, 0, dados, 6);
    
    return 0;
}

// Processa mensagens de descoberta e anúncio
int rede_processar_descoberta(Frame *frame, uint8_t *mac_origem, EnderecoMAC *endereco_destino, int modo_servidor) {
    uint8_t tipo = frame->sequencia_tipo & 0x0F;
    
    // Verifica se é um tipo de mensagem de descoberta relevante
    if ((modo_servidor && tipo == TIPO_DESCOBERTA_CLIENTE) ||
        (!modo_servidor && tipo == TIPO_ANUNCIO_SERVIDOR)) {
        
        // Verifica se o frame contém um MAC válido (6 bytes)
        if (frame->tamanho == 6) {
            // Atualiza o endereço MAC descoberto
            memcpy(endereco_destino->mac, frame->dados, 6);
            endereco_destino->descoberto = 1;
            endereco_destino->ultima_comunicacao = time(NULL);
            
            printf("[DESCOBERTA] %s descoberto: %02x:%02x:%02x:%02x:%02x:%02x\n",
                   modo_servidor ? "Cliente" : "Servidor",
                   endereco_destino->mac[0], endereco_destino->mac[1], endereco_destino->mac[2],
                   endereco_destino->mac[3], endereco_destino->mac[4], endereco_destino->mac[5]);
            
            return 1; // MAC descoberto com sucesso
        }
    }
    
    return 0; // Não é uma mensagem de descoberta relevante
}

// Verifica se a sequência recebida é a próxima esperada
int rede_verificar_sequencia(uint8_t seq_recebida, uint8_t seq_esperada) {
    return seq_recebida == seq_esperada;
}

// Envia um frame e aguarda confirmação (ACK)
int rede_enviar_com_confirmacao(int sock, const uint8_t *dest_mac, const char *interface, 
                               uint8_t tipo, uint8_t *dados, uint8_t tamanho, EstadoConexao *estado) {
    
    // Salva os dados do frame para possível retransmissão
    estado->ultima_tipo_enviado = tipo;
    estado->ultimo_tamanho_enviado = tamanho;
    if (dados && tamanho > 0) {
        memcpy(estado->dados_ultimo_frame, dados, tamanho);
    }
    
    // Envia o frame
    rede_envia_frame(sock, dest_mac, interface, tipo, estado->proxima_seq_envio, dados, tamanho);
    estado->ultima_seq_enviada = estado->proxima_seq_envio;
    estado->aguardando_ack = 1;
    
    // Aguarda ACK com timeout
    time_t inicio = time(NULL);
    Frame frame_recebido;
    int resultado;
    
    while (1) {
        resultado = rede_recebe_frame(sock, &frame_recebido, estado->timeout_atual);
        
        if (resultado == 1) {
            // Frame recebido, verifica se é um ACK para o frame enviado
            uint8_t tipo_recebido = frame_recebido.sequencia_tipo & 0x0F;
            uint8_t seq_recebida = (frame_recebido.sequencia_tipo >> 3) & 0x1F;
            
            if (tipo_recebido == TIPO_ACK && seq_recebida == estado->ultima_seq_enviada) {
                // ACK recebido para o frame enviado
                printf("[SENDER] ACK recebido para sequência %d\n", seq_recebida);
                estado->ultima_seq_confirmada = estado->ultima_seq_enviada;
                estado->proxima_seq_envio = seq_incrementar(estado->proxima_seq_envio);
                estado->timeout_atual = TIMEOUT_INICIAL; // Reset do timeout
                estado->retransmissoes = 0;
                estado->aguardando_ack = 0;
                return 1; // Sucesso
            } else if (tipo_recebido == TIPO_NACK) {
                // NACK recebido, retransmite imediatamente
                printf("[SENDER] NACK recebido, retransmitindo frame (Seq: %d)\n", estado->ultima_seq_enviada);
                rede_envia_frame(sock, dest_mac, interface, estado->ultima_tipo_enviado, 
                                estado->ultima_seq_enviada, estado->dados_ultimo_frame, 
                                estado->ultimo_tamanho_enviado);
                // Reinicia o timer
                inicio = time(NULL);
            } else {
                // Outro tipo de frame, ignora
                printf("[SENDER] Recebido frame não esperado (Tipo: %d, Seq: %d)\n", tipo_recebido, seq_recebida);
            }
        } else if (resultado == 0) {
            // Timeout, verifica se deve retransmitir
            if (estado->retransmissoes >= MAX_RETRANSMISSOES) {
                printf("[SENDER] Máximo de retransmissões atingido para sequência %d\n", estado->ultima_seq_enviada);
                return -ERRO_MAX_RETRANSMISSOES;
            }
            
            // Retransmite o frame
            printf("[SENDER] Timeout, retransmitindo frame (Seq: %d, Tentativa: %d)\n", 
                   estado->ultima_seq_enviada, estado->retransmissoes + 1);
            rede_envia_frame(sock, dest_mac, interface, estado->ultima_tipo_enviado, 
                            estado->ultima_seq_enviada, estado->dados_ultimo_frame, 
                            estado->ultimo_tamanho_enviado);
            
            // Incrementa contador de retransmissões e aplica backoff exponencial
            estado->retransmissoes++;
            estado->timeout_atual = estado->timeout_atual * 2;
            if (estado->timeout_atual > TIMEOUT_MAXIMO) {
                estado->timeout_atual = TIMEOUT_MAXIMO;
            }
            
            // Reinicia o timer
            inicio = time(NULL);
        } else {
            // Erro na recepção
            printf("[SENDER] Erro ao receber ACK\n");
            return -1;
        }
        
        // Verifica se o tempo total de espera excedeu um limite (ex: 60 segundos)
        if (time(NULL) - inicio > 60) {
            printf("[SENDER] Tempo total de espera excedido\n");
            return -ERRO_TIMEOUT;
        }
    }
}

// Retransmite o último frame enviado
int rede_retransmitir_ultimo_frame(int sock, const uint8_t *dest_mac, const char *interface, EstadoConexao *estado) {
    if (!estado->aguardando_ack) {
        printf("[SENDER] Não há frame pendente para retransmissão\n");
        return 0;
    }
    
    printf("[SENDER] Retransmitindo último frame (Tipo: %d, Seq: %d)\n", 
           estado->ultima_tipo_enviado, estado->ultima_seq_enviada);
    
    rede_envia_frame(sock, dest_mac, interface, estado->ultima_tipo_enviado, 
                    estado->ultima_seq_enviada, estado->dados_ultimo_frame, 
                    estado->ultimo_tamanho_enviado);
    
    return 1;
}

// Processa um ACK ou NACK recebido
int rede_processar_ack_nack(Frame *frame, EstadoConexao *estado) {
    uint8_t tipo = frame->sequencia_tipo & 0x0F;
    uint8_t seq = (frame->sequencia_tipo >> 3) & 0x1F;
    
    if (tipo == TIPO_ACK) {
        if (seq == estado->ultima_seq_enviada) {
            // ACK recebido para o frame enviado
            printf("[SENDER] ACK processado para sequência %d\n", seq);
            estado->ultima_seq_confirmada = estado->ultima_seq_enviada;
            estado->proxima_seq_envio = seq_incrementar(estado->proxima_seq_envio);
            estado->timeout_atual = TIMEOUT_INICIAL; // Reset do timeout
            estado->retransmissoes = 0;
            estado->aguardando_ack = 0;
            return 1; // ACK válido
        } else {
            printf("[SENDER] ACK ignorado (Seq esperada: %d, Recebida: %d)\n", 
                   estado->ultima_seq_enviada, seq);
            return 0; // ACK para outro frame
        }
    } else if (tipo == TIPO_NACK) {
        // NACK recebido, indica retransmissão necessária
        printf("[SENDER] NACK recebido para sequência %d\n", seq);
        return -1; // Indica necessidade de retransmissão
    }
    
    return 0; // Não é ACK nem NACK
}



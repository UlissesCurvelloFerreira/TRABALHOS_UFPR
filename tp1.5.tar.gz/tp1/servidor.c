#include "protocolo.h"

#define PORTA_SERVIDOR 12345

// Variáveis globais
estado_protocolo_t estado_servidor;
estado_jogo_t jogo;

// Protótipos das funções
int inicializar_servidor();
int processar_mensagem_cliente();
int processar_movimento(tipo_msg_t direcao);
int enviar_mapa_cliente();
int enviar_tesouro(int indice_tesouro);
int enviar_arquivo_tesouro(const char* caminho_arquivo, const char* nome_arquivo, tipo_msg_t tipo);
void log_movimento(const char* direcao, int sucesso);

int main() {
    printf("=== SERVIDOR CAÇA AO TESOURO ===\n");
    
    // Inicializar servidor
    if (inicializar_servidor() < 0) {
        fprintf(stderr, "Erro ao inicializar servidor\n");
        return 1;
    }
    
    printf("Servidor iniciado na porta %d\n", PORTA_SERVIDOR);
    
    // Inicializar jogo
    inicializar_jogo(&jogo);
    mostrar_mapa_servidor(&jogo);
    
    printf("\nAguardando conexão do cliente...\n");
    
    // Loop principal do servidor
    while (1) {
        if (processar_mensagem_cliente() < 0) {
            continue; // Continuar aguardando próxima mensagem
        }
        
        // Verificar se jogo terminou
        if (jogo.tesouros_encontrados >= NUM_TESOUROS) {
            printf("\n🎉 JOGO CONCLUÍDO! Todos os tesouros foram encontrados!\n");
            
            // Enviar mensagem de fim de jogo
            frame_t frame_fim;
            criar_frame(&frame_fim, estado_servidor.seq_atual, TIPO_FIM_JOGO, NULL, 0);
            enviar_frame(&estado_servidor, &frame_fim);
            
            printf("Reiniciando jogo...\n");
            inicializar_jogo(&jogo);
            mostrar_mapa_servidor(&jogo);
        }
    }
    
    close(estado_servidor.socket_fd);
    return 0;
}

int inicializar_servidor() {
    // Criar socket UDP
    estado_servidor.socket_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (estado_servidor.socket_fd < 0) {
        perror("Erro ao criar socket");
        return -1;
    }
    
    // Configurar endereço do servidor
    struct sockaddr_in endereco_servidor;
    memset(&endereco_servidor, 0, sizeof(endereco_servidor));
    endereco_servidor.sin_family = AF_INET;
    endereco_servidor.sin_addr.s_addr = INADDR_ANY;
    endereco_servidor.sin_port = htons(PORTA_SERVIDOR);
    
    // Bind do socket
    if (bind(estado_servidor.socket_fd, (struct sockaddr*)&endereco_servidor, 
             sizeof(endereco_servidor)) < 0) {
        perror("Erro no bind");
        close(estado_servidor.socket_fd);
        return -1;
    }
    
    // Inicializar estado
    estado_servidor.seq_atual = 0;
    estado_servidor.seq_esperada = 0;
    estado_servidor.tamanho_endereco = sizeof(estado_servidor.endereco_remoto);
    
    return 0;
}

int processar_mensagem_cliente() {
    frame_t frame_recebido;
    
    // Receber frame do cliente
    int result = receber_frame(&estado_servidor, &frame_recebido);
    if (result < 0) {
        if (result == -2) {
            // Timeout normal
            return 0;
        }
        return -1;
    }
    
    // Processar mensagem baseado no tipo
    switch (frame_recebido.tipo) {
        case TIPO_INICIAR_JOGO:
            printf("Cliente solicitou início do jogo\n");
            jogo.jogo_iniciado = 1;
            
            // Enviar ACK
            enviar_ack(&estado_servidor, frame_recebido.sequencia);
            
            // Enviar mapa inicial
            return enviar_mapa_cliente();
            
        case TIPO_DESLOCA_DIREITA:
            return processar_movimento(TIPO_DESLOCA_DIREITA);
            
        case TIPO_DESLOCA_ESQUERDA:
            return processar_movimento(TIPO_DESLOCA_ESQUERDA);
            
        case TIPO_DESLOCA_CIMA:
            return processar_movimento(TIPO_DESLOCA_CIMA);
            
        case TIPO_DESLOCA_BAIXO:
            return processar_movimento(TIPO_DESLOCA_BAIXO);
            
        default:
            printf("Tipo de mensagem não reconhecido: %d\n", frame_recebido.tipo);
            return enviar_erro(&estado_servidor, frame_recebido.sequencia, ERRO_SEM_PERMISSAO);
    }
}

int processar_movimento(tipo_msg_t direcao) {
    const char* nome_direcao;
    switch (direcao) {
        case TIPO_DESLOCA_DIREITA: nome_direcao = "DIREITA"; break;
        case TIPO_DESLOCA_ESQUERDA: nome_direcao = "ESQUERDA"; break;
        case TIPO_DESLOCA_CIMA: nome_direcao = "CIMA"; break;
        case TIPO_DESLOCA_BAIXO: nome_direcao = "BAIXO"; break;
        default: nome_direcao = "DESCONHECIDA"; break;
    }
    
    // Tentar mover jogador
    if (mover_jogador(&jogo, direcao) < 0) {
        printf("❌ Movimento %s inválido - posição atual: (%d,%d)\n", 
               nome_direcao, jogo.posicao_jogador.x, jogo.posicao_jogador.y);
        log_movimento(nome_direcao, 0);
        
        // Enviar erro de movimento inválido
        return enviar_erro(&estado_servidor, estado_servidor.seq_atual, ERRO_MOVIMENTO_INVALIDO);
    }
    
    printf("✅ Movimento %s realizado - nova posição: (%d,%d)\n", 
           nome_direcao, jogo.posicao_jogador.x, jogo.posicao_jogador.y);
    log_movimento(nome_direcao, 1);
    
    // Mostrar mapa atualizado
    mostrar_mapa_servidor(&jogo);
    
    // Verificar se há tesouro na nova posição
    int indice_tesouro = verificar_tesouro(&jogo, jogo.posicao_jogador);
    if (indice_tesouro >= 0) {
        printf("🏆 TESOURO ENCONTRADO! %s na posição (%d,%d)\n", 
               jogo.tesouros[indice_tesouro].nome_arquivo,
               jogo.posicao_jogador.x, jogo.posicao_jogador.y);
        
        // Enviar tesouro para o cliente
        return enviar_tesouro(indice_tesouro);
    } else {
        // Apenas enviar nova posição
        return enviar_mapa_cliente();
    }
}

int enviar_mapa_cliente() {
    frame_t frame_mapa;
    mapa_cliente_t mapa_dados;
    
    // Preparar dados do mapa para o cliente
    mapa_dados.posicao_jogador = jogo.posicao_jogador;
    mapa_dados.tesouros_encontrados = jogo.tesouros_encontrados;
    
    // Copiar grid visitado
    memcpy(mapa_dados.grid_visitado, jogo.grid_visitado, sizeof(jogo.grid_visitado));
    
    // Preparar grid de tesouros (apenas tesouros encontrados)
    memset(mapa_dados.grid_tesouros, 0, sizeof(mapa_dados.grid_tesouros));
    for (int i = 0; i < NUM_TESOUROS; i++) {
        if (jogo.tesouros[i].encontrado) {
            mapa_dados.grid_tesouros[jogo.tesouros[i].posicao.x][jogo.tesouros[i].posicao.y] = 1;
        }
    }
    
    // Criar e enviar frame
    estado_servidor.seq_atual = (estado_servidor.seq_atual + 1) % 32;
    criar_frame(&frame_mapa, estado_servidor.seq_atual, TIPO_MAPA_CLIENTE, 
                (unsigned char*)&mapa_dados, sizeof(mapa_dados));
    
    return enviar_frame(&estado_servidor, &frame_mapa);
}

int enviar_tesouro(int indice_tesouro) {
    tesouro_t* tesouro = &jogo.tesouros[indice_tesouro];
    
    // Primeiro enviar informação de tesouro encontrado
    frame_t frame_tesouro;
    estado_servidor.seq_atual = (estado_servidor.seq_atual + 1) % 32;
    
    unsigned char dados_tesouro[64 + 1]; // nome + tipo
    dados_tesouro[0] = (unsigned char)tesouro->tipo;
    memcpy(dados_tesouro + 1, tesouro->nome_arquivo, strlen(tesouro->nome_arquivo));
    
    criar_frame(&frame_tesouro, estado_servidor.seq_atual, TIPO_TESOURO_ENCONTRADO, 
                dados_tesouro, strlen(tesouro->nome_arquivo) + 1);
    
    if (enviar_frame(&estado_servidor, &frame_tesouro) < 0) {
        return -1;
    }
    
    // Aguardar ACK
    if (esperar_ack(&estado_servidor) < 0) {
        return -1;
    }
    
    // Determinar tipo de arquivo para protocolo
    tipo_msg_t tipo_protocolo;
    switch (tesouro->tipo) {
        case TESOURO_TEXTO:
            tipo_protocolo = TIPO_TEXTO_ACK_NOME;
            break;
        case TESOURO_IMAGEM:
            tipo_protocolo = TIPO_IMAGEM_ACK_NOME;
            break;
        case TESOURO_VIDEO:
            tipo_protocolo = TIPO_VIDEO_ACK_NOME;
            break;
        default:
            tipo_protocolo = TIPO_TEXTO_ACK_NOME;
            break;
    }
    
    // Enviar arquivo do tesouro
    int result = enviar_arquivo_tesouro(tesouro->caminho_completo, tesouro->nome_arquivo, tipo_protocolo);
    
    if (result == 0) {
        // Enviar mapa atualizado
        enviar_mapa_cliente();
    }
    
    return result;
}

int enviar_arquivo_tesouro(const char* caminho_arquivo, const char* nome_arquivo, tipo_msg_t tipo) {
    FILE* arquivo = fopen(caminho_arquivo, "rb");
    if (!arquivo) {
        perror("Erro ao abrir arquivo de tesouro");
        return -1;
    }
    
    unsigned long tamanho_arquivo = obter_tamanho_arquivo(caminho_arquivo);
    printf("Enviando tesouro: %s (%lu bytes)\n", nome_arquivo, tamanho_arquivo);
    
    // Enviar nome do arquivo
    estado_servidor.seq_atual = (estado_servidor.seq_atual + 1) % 32;
    frame_t frame_nome;
    criar_frame(&frame_nome, estado_servidor.seq_atual, tipo, 
                (unsigned char*)nome_arquivo, strlen(nome_arquivo));
    
    if (enviar_frame(&estado_servidor, &frame_nome) < 0) {
        fclose(arquivo);
        return -1;
    }
    
    if (esperar_ack(&estado_servidor) < 0) {
        fclose(arquivo);
        return -1;
    }
    
    // Enviar tamanho do arquivo
    estado_servidor.seq_atual = (estado_servidor.seq_atual + 1) % 32;
    unsigned char dados_tamanho[4];
    dados_tamanho[0] = (tamanho_arquivo >> 24) & 0xFF;
    dados_tamanho[1] = (tamanho_arquivo >> 16) & 0xFF;
    dados_tamanho[2] = (tamanho_arquivo >> 8) & 0xFF;
    dados_tamanho[3] = tamanho_arquivo & 0xFF;
    
    frame_t frame_tamanho;
    criar_frame(&frame_tamanho, estado_servidor.seq_atual, TIPO_TAMANHO, dados_tamanho, 4);
    
    if (enviar_frame(&estado_servidor, &frame_tamanho) < 0) {
        fclose(arquivo);
        return -1;
    }
    
    if (esperar_ack(&estado_servidor) < 0) {
        fclose(arquivo);
        return -1;
    }
    
    // Enviar dados do arquivo
    unsigned char buffer[MAX_DADOS];
    size_t bytes_lidos;
    unsigned long total_enviado = 0;
    
    while ((bytes_lidos = fread(buffer, 1, MAX_DADOS, arquivo)) > 0) {
        estado_servidor.seq_atual = (estado_servidor.seq_atual + 1) % 32;
        frame_t frame_dados;
        
        criar_frame(&frame_dados, estado_servidor.seq_atual, TIPO_DADOS, buffer, bytes_lidos);
        
        if (enviar_frame(&estado_servidor, &frame_dados) < 0) {
            fclose(arquivo);
            return -1;
        }
        
        if (esperar_ack(&estado_servidor) < 0) {
            fclose(arquivo);
            return -1;
        }
        
        total_enviado += bytes_lidos;
    }
    
    fclose(arquivo);
    
    // Enviar fim de arquivo
    estado_servidor.seq_atual = (estado_servidor.seq_atual + 1) % 32;
    frame_t frame_fim;
    criar_frame(&frame_fim, estado_servidor.seq_atual, TIPO_FIM_ARQUIVO, NULL, 0);
    
    if (enviar_frame(&estado_servidor, &frame_fim) < 0) {
        return -1;
    }
    
    if (esperar_ack(&estado_servidor) < 0) {
        return -1;
    }
    
    printf("Tesouro %s enviado com sucesso!\n", nome_arquivo);
    return 0;
}

void log_movimento(const char* direcao, int sucesso) {
    time_t now = time(NULL);
    char* time_str = ctime(&now);
    time_str[strlen(time_str) - 1] = '\0'; // Remover \n
    
    printf("[%s] Movimento %s: %s - Posição: (%d,%d) - Tesouros: %d/%d\n",
           time_str, direcao, sucesso ? "OK" : "INVÁLIDO",
           jogo.posicao_jogador.x, jogo.posicao_jogador.y,
           jogo.tesouros_encontrados, NUM_TESOUROS);
}
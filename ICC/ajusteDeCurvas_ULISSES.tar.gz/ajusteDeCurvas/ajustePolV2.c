#include <stdio.h>
#include <stdlib.h>
#include <float.h>
#include <fenv.h>
#include <math.h>
#include <stdint.h>
#include <likwid.h>

#include "utils.h"

typedef double * Matriz;
typedef double * Vetor;

/////////////////////////////////////////////////////////////////////////////////////
//   AJUSTE DE CURVAS
/////////////////////////////////////////////////////////////////////////////////////

void montaSL(Matriz A, Vetor b, int n, long long int p, double *x, double *y) {

  for(int i = 0; i < n; ++i) {
      for (int j = 0; j < n; ++j)
          A[n*i + j] = 0.0;
  }

  for (long long int k = 0; k < p; ++k) {
    for (int i = 0; i < n; ++i) {
      double pow_x = 1.0;
      for (int aux = 0; aux < i; ++aux) pow_x *= x[k];
      
      for (int j = 0; j+3 < n; j+=4) {
          A[n*i+j] += pow_x;
          A[n*i+j+1] += pow_x * x[k];
          A[n*i+j+2] += A[n*i+j+1] * x[k];
          A[n*i+j+3] += A[n*i+j+2] * x[k];

          pow_x *= x[k] * x[k] * x[k] * x[k];
      }
    }

    for (int i = 0; i < n; ++i) {
      for (int j = n-n%4; j < n; ++j){
          double poww = 1.0;
          for (int aux = 0; aux < i+j; ++aux) poww *= x[k];
          A[n*i + j] += poww;
      }
    }
  }

  for (int i = 0; i < n; ++i)
      b[i] = 0.0;
  for (long long int k = 0; k < p; ++k) {
    double pow_x = 1.0;
    for (int i = 0; i+3 < n; i+=4) {
        b[i] += pow_x * y[k];
        b[i+1] += b[i] * x[k];
        b[i+2] += b[i+1] * x[k];
        b[i+3] += b[i+2] * x[k];

        pow_x *= x[k] * x[k] * x[k] * x[k];
    }
    for(int i = n-n%4; i < n; ++i) {
        b[i] += pow_x * y[k];
        pow_x *= x[k];
    }
  }
}

void eliminacaoGauss(Matriz A, Vetor b, int n) {
  for (int i = 0; i < n; ++i) {
    int iMax = i;
    for (int k = i+1; k < n; ++k)
      if (A[n*k+i] > A[n*iMax+i])
	      iMax = k;

    if (iMax != i) {
      double aux;
      for(int j = 0; j < n; ++j) {
          aux         = A[n*i+j];
          A[n*i+j]    = A[n*iMax+j];
          A[n*iMax+j] = aux;
      }
      aux     = b[i];
      b[i]    = b[iMax];
      b[iMax] = aux;
    }

    for (int k = i+1; k < n; ++k) {
      double m = A[n*k+i] / A[n*i+i];
      A[n*k+i]  = 0.0;
      for (int j = i+1; j < n; ++j) A[n*k+j] -= A[n*i+j]*m;
      b[k] -= b[i]*m;
    }
  }
}

void retrossubs(Matriz A, Vetor b, Vetor x, int n) {
  for (int i = n-1; i >= 0; --i) {
    x[i] = b[i];
    for (int j = i+1; j < n; ++j) x[i] -= A[n*i + j]*x[j];
    x[i] /= A[n*i + i];
  }
}

double P(double x, int N, Vetor alpha) {
  double Px = alpha[0];
  for (int i = 1; i <= N; ++i){
    double poww = 1.0;
    for (int aux = 0; aux < i; ++aux) poww *= x;
    Px += alpha[i]*poww;
  }
  return Px;
}

int main() {
  LIKWID_MARKER_INIT;

  int N, n;
  long long int K, p;

  scanf("%d %lld", &N, &K);
  p = K;   // quantidade de pontos
  n = N+1; // tamanho do SL (grau N + 1)

  Vetor x = (double *) malloc(sizeof(double)*p);
  Vetor y = (double *) malloc(sizeof(double)*p);

  // ler numeros
  for (long long int i = 0; i < p; ++i)
    scanf("%lf %lf", x+i, y+i);

  Matriz A = (double *) malloc(n*n*sizeof(double));
  
  Vetor b = (double *) malloc(sizeof(double)*n);
  Vetor alpha = (double *) malloc(sizeof(double)*n); // coeficientes ajuste

  // (A) Gera SL
  double tSL = timestamp();
  LIKWID_MARKER_START("SL");
  montaSL(A, b, n, p, x, y);
  LIKWID_MARKER_STOP("SL");
  tSL = timestamp() - tSL;

  // (B) Resolve SL
  double tEG = timestamp();
  LIKWID_MARKER_START("EG");
  eliminacaoGauss(A, b, n); 
  retrossubs(A, b, alpha, n);
  LIKWID_MARKER_STOP("EG");
  tEG = timestamp() - tEG;

  // Imprime coeficientes
  for (int i = 0; i < n; ++i)
    printf("%1.15e ", alpha[i]);
  puts("");

  // Imprime resíduos
  for (long long int i = 0; i < p; ++i)
    printf("%1.15e ", fabs(y[i] - P(x[i],N,alpha)) );
  puts("");

  // Imprime os tempos
  printf("%lld %1.10e %1.10e\n", K, tSL, tEG);

  LIKWID_MARKER_CLOSE;
  return 0;
}

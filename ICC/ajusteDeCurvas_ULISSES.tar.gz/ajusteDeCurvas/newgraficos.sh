#!/usr/bin/gnuplot -c

set encoding utf
set xlabel "Num de Pontos"
set grid
set style data points
set style function lines
set xtics
set boxwidth 1
set style line 2 lc 3 pt 7 ps 0.3
set datafile separator space
set logscale x

# ===============================================================

# Plot de Tempo (Log Y)
set ylabel "Tempo"
set logscale y

set title "Teste de tempo MQ"
set terminal qt 0 title "Teste de tempo MQ"
plot 'tempo.dat' using 1:2 title "N1+v1" with linespoints, \
     '' using 1:6 title "N2+v1" with linespoints, \
     '' using 1:4 title "N1+v2" with linespoints, \
     '' using 1:8 title "N2+v2" with linespoints
pause -1

set title "Teste de tempo EG"
set terminal qt 0 title "Teste de tempo EG"
plot 'tempo.dat' using 1:3 title "N1+v1" with linespoints, \
     '' using 1:7 title "N2+v1" with linespoints, \
     '' using 1:5 title "N1+v2" with linespoints, \
     '' using 1:9 title "N2+v2" with linespoints
pause -1

unset logscale y

# ===============================================================

set title "Cache miss L3 MQ"
set terminal qt 0 title "Cache miss L3 MQ"
plot 'l3cache.dat' using 1:2 title "N1+v1" with linespoints, \
     '' using 1:6 title "N2+v1" with linespoints, \
     '' using 1:4 title "N1+v2" with linespoints, \
     '' using 1:8 title "N2+v2" with linespoints
pause -1

set title "Cache miss L3 EG"
set terminal qt 0 title "Cache miss L3 EG"
plot 'l3cache.dat' using 1:3 title "N1+v1" with linespoints, \
     '' using 1:7 title "N2+v1" with linespoints, \
     '' using 1:5 title "N1+v2" with linespoints, \
     '' using 1:9 title "N2+v2" with linespoints
pause -1

# ===============================================================

set title "Energia MQ"
set terminal qt 0 title "Energia MQ"
set terminal qt 0 title "Cache miss L3 MQ"
plot 'energy.dat' using 1:2 title "N1+v1" with linespoints, \
     '' using 1:6 title "N2+v1" with linespoints, \
     '' using 1:4 title "N1+v2" with linespoints, \
     '' using 1:8 title "N2+v2" with linespoints
pause -1

set title "Energia EG"
set terminal qt 0 title "Energia EG"
plot 'energy.dat' using 1:3 title "N1+v1" with linespoints, \
     '' using 1:7 title "N2+v1" with linespoints, \
     '' using 1:5 title "N1+v2" with linespoints, \
     '' using 1:9 title "N2+v2" with linespoints
pause -1

# ===============================================================

set title "FLOPS DP MQ"
set terminal qt 0 title "FLOPS DP MQ"
plot 'flops_dp.dat' using 1:2 title "N1+v1" with linespoints, \
     '' using 1:6 title "N2+v1" with linespoints, \
     '' using 1:4 title "N1+v2" with linespoints, \
     '' using 1:8 title "N2+v2" with linespoints
pause -1

set title "FLOPS DP EG"
set terminal qt 0 title "FLOPS DP EG"
plot 'flops_dp.dat' using 1:3 title "N1+v1" with linespoints, \
     '' using 1:7 title "N2+v1" with linespoints, \
     '' using 1:5 title "N1+v2" with linespoints, \
     '' using 1:9 title "N2+v2" with linespoints
pause -1

# ===============================================================

set title "FLOPS AVX DP MQ"
set terminal qt 0 title "FLOPS AVX DP MQ"
set terminal qt 0 title "Cache miss L3 MQ"
plot 'flops_avx_dp.dat' using 1:2 title "N1+v1" with linespoints, \
     '' using 1:6 title "N2+v1" with linespoints, \
     '' using 1:4 title "N1+v2" with linespoints, \
     '' using 1:8 title "N2+v2" with linespoints
pause -1

set title "FLOPS AVX DP EG"
set terminal qt 0 title "FLOPS AVX DP EG"
plot 'flops_avx_dp.dat' using 1:3 title "N1+v1" with linespoints, \
     '' using 1:7 title "N2+v1" with linespoints, \
     '' using 1:5 title "N1+v2" with linespoints, \
     '' using 1:9 title "N2+v2" with linespoints
pause -1

# ===============================================================
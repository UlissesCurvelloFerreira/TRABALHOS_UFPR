#!/bin/bash
# chmod +x teste.sh
# ./teste.sh ajustePolv1 ajustePolv2 3

# Arrays de teste
N=(10 1000)
K=(64 128 200 256 512 600 800 1024 2000 3000 4096 6000 7000 10000 50000 100000 1000000 10000000 100000000)

LIKWID_CMD="likwid-perfctr -m -C $3 -g"

# Configura o governador da CPU para performance
echo "performance" > /sys/devices/system/cpu/cpufreq/policy3/scaling_governor


# Compilação e limpeza inicial
#make purge gera_entrada $1 $2
rm -f *.dat

temp_files=(tempo.dat l3cache.dat energy.dat flops_dp.dat flops_avx_dp.dat)

# Loop principal
for k in "${K[@]}"
do
    echo "Testando para K=$k..."

    # Adiciona o valor de K nos arquivos de saída
    for file in "${temp_files[@]}"; do
        echo -n "$k " >> $file
    done

    for n in "${N[@]}"
    do
        # Pula o caso K > 100000 e N = 1000
        if [[ $k -gt 100000 && $n -eq 1000 ]]; then
            continue
        fi

        echo "  Testando para N=$n..."

        # Gera entrada
        ./gera_entrada $k $n > entrada.dat

        # Função para medir desempenho com LIKWID
        function measure() {
            local metric=$1
            local program=$2
            cat entrada.dat | likwid-perfctr -C 3 -g $metric -m ./$program
        }

        # L3 Miss Ratio
        for prog in $1 $2; do # [v1 10 Gera SL] [v1 10 Resolve SL] [v2 10 Gera SL] [v2 10 Resolve SL] [v1 1000 Gera SL] [v1 1000 Resolve SL] [v2 1000 Gera SL] [v2 1000 Resolve SL]
            measure L3CACHE $prog |
                awk -F'|' 'BEGIN {ORS=" "}; $2 ~ /L3 miss ratio/ {gsub (" ", "", $3); print $3}' >> l3cache.dat
        done

        # Energia
        for prog in $1 $2; do # [v1 10 Gera SL] [v1 10 Resolve SL] [v2 10 Gera SL] [v2 10 Resolve SL] [v1 1000 Gera SL] [v1 1000 Resolve SL] [v2 1000 Gera SL] [v2 1000 Resolve SL]
            measure ENERGY $prog |
                awk -F'|' '$2 ~ /Energy/ {gsub (" ", "", $3); print $3}' |
                awk 'BEGIN {ORS=" "}; (NR-1) % 4 == 0 {print}' >> energy.dat
        done

        # FLOPs e AVX
        for prog in $1 $2; do # [v1 10 Gera SL] [v1 10 Resolve SL] [v2 10 Gera SL] [v2 10 Resolve SL] [v1 1000 Gera SL] [v1 1000 Resolve SL] [v2 1000 Gera SL] [v2 1000 Resolve SL]
            measure FLOPS_DP $prog > temp.dat
            awk -F'|' '$2 ~ /DP/ {print $2 $3}' temp.dat |
                awk 'BEGIN {ORS=" "}; $1 !~ /AVX/ {print $3}' >> flops_dp.dat
            awk -F'|' 'BEGIN {ORS=" "}; $2 ~ /AVX/ {gsub (" ", "", $3); print $3}' temp.dat >> flops_avx_dp.dat
            awk 'BEGIN {ORS=" "}; NR == 8 {print $2, $3}' temp.dat >> tempo.dat
        done

        rm -f entrada.dat
        echo "  Concluído."
    done

    # Adiciona nova linha nos arquivos de saída
    for file in "${temp_files[@]}"; do
        echo "" >> $file
    done

done

# Limpeza final
echo "powersave" > /sys/devices/system/cpu/cpufreq/policy3/scaling_governor
rm -f temp.dat

echo "Testes concluídos."
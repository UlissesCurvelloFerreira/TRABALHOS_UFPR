#ifndef PROTOCOLO_H
#define PROTOCOLO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <errno.h>


#include <unistd.h>      // Para usleep()
#include <sys/time.h>    // Para struct timeval
#include <strings.h>     // Para strcasecmp()

// Constantes do protocolo
#define MAX_DADOS 512
#define MAX_TENTATIVAS 3
#define TIMEOUT_SEGUNDOS 5
#define TOLERANCIA_ESPACO 1048576  // 1MB

// Constantes do jogo
#define TAMANHO_GRID 8
#define NUM_TESOUROS 8
#define DIRETORIO_OBJETOS "./objetos/"

// Tipos de mensagem
typedef enum {
    TIPO_ACK = 0,
    TIPO_NACK = 1,
    TIPO_ERRO = 2,
    TIPO_DADOS = 3,
    TIPO_FIM_ARQUIVO = 4,
    TIPO_TAMANHO = 5,
    TIPO_TEXTO_ACK_NOME = 6,
    TIPO_IMAGEM_ACK_NOME = 7,
    TIPO_VIDEO_ACK_NOME = 8,
    // Novos tipos para o jogo
    TIPO_INICIAR_JOGO = 9,
    TIPO_DESLOCA_DIREITA = 10,
    TIPO_DESLOCA_ESQUERDA = 11,
    TIPO_DESLOCA_CIMA = 12,
    TIPO_DESLOCA_BAIXO = 13,
    TIPO_POSICAO_ATUAL = 14,
    TIPO_TESOURO_ENCONTRADO = 15,
    TIPO_MAPA_CLIENTE = 16,
    TIPO_MOVIMENTO_INVALIDO = 17,
    TIPO_FIM_JOGO = 18
} tipo_msg_t;

// Tipos de erro
typedef enum {
    ERRO_ARQUIVO_NAO_ENCONTRADO = 1,
    ERRO_SEM_PERMISSAO = 2,
    ERRO_ESPACO_INSUFICIENTE = 3,
    ERRO_ARQUIVO_MUITO_GRANDE = 4,
    ERRO_MOVIMENTO_INVALIDO = 5
} tipo_erro_t;

// Tipos de tesouro
typedef enum {
    TESOURO_TEXTO = 0,
    TESOURO_IMAGEM = 1,
    TESOURO_VIDEO = 2
} tipo_tesouro_t;

// Estrutura de posição
typedef struct {
    int x;
    int y;
} posicao_t;

// Estrutura de tesouro
typedef struct {
    posicao_t posicao;
    char nome_arquivo[64];
    char caminho_completo[256];
    unsigned long tamanho;
    tipo_tesouro_t tipo;
    int encontrado;
} tesouro_t;

// Estrutura de frame do protocolo
typedef struct {
    unsigned char sequencia;
    tipo_msg_t tipo;
    unsigned short tamanho;
    unsigned char dados[MAX_DADOS];
} frame_t;

// Estado do protocolo
typedef struct {
    int socket_fd;
    struct sockaddr_in endereco_remoto;
    socklen_t tamanho_endereco;
    unsigned char seq_atual;
    unsigned char seq_esperada;
} estado_protocolo_t;

// Estado do jogo
typedef struct {
    posicao_t posicao_jogador;
    tesouro_t tesouros[NUM_TESOUROS];
    int grid_visitado[TAMANHO_GRID][TAMANHO_GRID];
    int tesouros_encontrados;
    int jogo_iniciado;
} estado_jogo_t;

// Estrutura para informações do mapa do cliente
typedef struct {
    posicao_t posicao_jogador;
    int grid_visitado[TAMANHO_GRID][TAMANHO_GRID];
    int grid_tesouros[TAMANHO_GRID][TAMANHO_GRID]; // 0=vazio, 1=tesouro encontrado
    int tesouros_encontrados;
} mapa_cliente_t;

// Estrutura para o estado do cliente
typedef struct {
    estado_protocolo_t protocolo;
    mapa_cliente_t mapa_atual;
    int jogo_ativo;
    int tesouros_coletados;
} estado_cliente_t;




// Funções do protocolo
int criar_frame(frame_t* frame, unsigned char seq, tipo_msg_t tipo, 
                const unsigned char* dados, unsigned short tamanho);
int enviar_frame(estado_protocolo_t* estado, const frame_t* frame);
int receber_frame(estado_protocolo_t* estado, frame_t* frame);
int enviar_ack(estado_protocolo_t* estado, unsigned char seq);
int enviar_nack(estado_protocolo_t* estado, unsigned char seq);
int enviar_erro(estado_protocolo_t* estado, unsigned char seq, tipo_erro_t erro);
int esperar_ack(estado_protocolo_t* estado);

// Funções do jogo
void inicializar_jogo(estado_jogo_t* jogo);
int mover_jogador(estado_jogo_t* jogo, tipo_msg_t direcao);
int verificar_tesouro(estado_jogo_t* jogo, posicao_t posicao);
void mostrar_mapa_servidor(estado_jogo_t* jogo);
void mostrar_mapa_cliente(mapa_cliente_t* mapa);

// Funções auxiliares
unsigned long obter_tamanho_arquivo(const char* caminho);
unsigned long obter_espaco_livre(const char* diretorio);
int is_arquivo_regular(const char* caminho);
tipo_msg_t determinar_tipo_arquivo(const char* nome_arquivo);

#endif // PROTOCOLO_H

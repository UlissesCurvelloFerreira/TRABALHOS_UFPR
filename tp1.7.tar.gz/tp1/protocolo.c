#include "protocolo.h"

int criar_frame(frame_t* frame, unsigned char seq, tipo_msg_t tipo, 
                const unsigned char* dados, unsigned short tamanho) {
    if (!frame || tamanho > MAX_DADOS) {
        return -1;
    }
    
    frame->sequencia = seq;
    frame->tipo = tipo;
    frame->tamanho = tamanho;
    
    if (dados && tamanho > 0) {
        memcpy(frame->dados, dados, tamanho);
    }
    
    return 0;
}

int enviar_frame(estado_protocolo_t* estado, const frame_t* frame) {
    if (!estado || !frame) {
        return -1;
    }
    
    // Montar buffer para envio
    unsigned char buffer[sizeof(frame_t)];
    buffer[0] = frame->sequencia;
    buffer[1] = (unsigned char)frame->tipo;
    buffer[2] = (frame->tamanho >> 8) & 0xFF;
    buffer[3] = frame->tamanho & 0xFF;
    
    memcpy(buffer + 4, frame->dados, frame->tamanho);
    
    int tamanho_total = 4 + frame->tamanho;
    
    for (int tentativa = 0; tentativa < MAX_TENTATIVAS; tentativa++) {
        ssize_t bytes_enviados = sendto(estado->socket_fd, buffer, tamanho_total, 0,
                                       (struct sockaddr*)&estado->endereco_remoto,
                                       estado->tamanho_endereco);
        
        if (bytes_enviados == tamanho_total) {
            return 0;
        }
        
        if (bytes_enviados < 0) {
            perror("Erro no sendto");
        }
        
        usleep(100000); // 100ms entre tentativas
    }
    
    return -1;
}

int receber_frame(estado_protocolo_t* estado, frame_t* frame) {
    if (!estado || !frame) {
        return -1;
    }
    
    // Configurar timeout
    struct timeval timeout;
    timeout.tv_sec = TIMEOUT_SEGUNDOS;
    timeout.tv_usec = 0;
    
    if (setsockopt(estado->socket_fd, SOL_SOCKET, SO_RCVTIMEO, 
                   &timeout, sizeof(timeout)) < 0) {
        perror("Erro ao configurar timeout");
        return -1;
    }
    
    unsigned char buffer[sizeof(frame_t)];
    
    ssize_t bytes_recebidos = recvfrom(estado->socket_fd, buffer, sizeof(buffer), 0,
                                      (struct sockaddr*)&estado->endereco_remoto,
                                      &estado->tamanho_endereco);
    
    if (bytes_recebidos < 0) {
        if (errno == EAGAIN || errno == EWOULDBLOCK) {
            return -2; // Timeout
        }
        perror("Erro no recvfrom");
        return -1;
    }
    
    if (bytes_recebidos < 4) {
        fprintf(stderr, "Frame muito pequeno recebido\n");
        return -1;
    }
    
    // Decodificar frame
    frame->sequencia = buffer[0];
    frame->tipo = (tipo_msg_t)buffer[1];
    frame->tamanho = (buffer[2] << 8) | buffer[3];
    
    if (frame->tamanho > MAX_DADOS || bytes_recebidos != (4 + frame->tamanho)) {
        fprintf(stderr, "Tamanho de frame inválido\n");
        return -1;
    }
    
    if (frame->tamanho > 0) {
        memcpy(frame->dados, buffer + 4, frame->tamanho);
    }
    
    return 0;
}

int enviar_ack(estado_protocolo_t* estado, unsigned char seq) {
    frame_t frame_ack;
    criar_frame(&frame_ack, seq, TIPO_ACK, NULL, 0);
    return enviar_frame(estado, &frame_ack);
}

int enviar_nack(estado_protocolo_t* estado, unsigned char seq) {
    frame_t frame_nack;
    criar_frame(&frame_nack, seq, TIPO_NACK, NULL, 0);
    return enviar_frame(estado, &frame_nack);
}

int enviar_erro(estado_protocolo_t* estado, unsigned char seq, tipo_erro_t erro) {
    frame_t frame_erro;
    unsigned char dados_erro = (unsigned char)erro;
    criar_frame(&frame_erro, seq, TIPO_ERRO, &dados_erro, 1);
    return enviar_frame(estado, &frame_erro);
}

int esperar_ack(estado_protocolo_t* estado) {
    frame_t resposta;
    
    int result = receber_frame(estado, &resposta);
    if (result < 0) {
        return result;
    }
    
    if (resposta.tipo == TIPO_ACK) {
        return 0;
    } else if (resposta.tipo == TIPO_NACK) {
        return -3; // NACK recebido
    } else if (resposta.tipo == TIPO_ERRO) {
        return -4; // Erro recebido
    }
    
    return -1; // Resposta inesperada
}

void inicializar_jogo(estado_jogo_t* jogo) {
    if (!jogo) return;
    
    // Limpar estruturas
    memset(jogo, 0, sizeof(estado_jogo_t));
    
    // Posição inicial do jogador
    jogo->posicao_jogador.x = 0;
    jogo->posicao_jogador.y = 0;
    jogo->grid_visitado[0][0] = 1;
    
    // Seed para random
    srand(time(NULL));
    
    // Sortear posições dos tesouros
    printf("Sorteando posições dos tesouros...\n");
    
    for (int i = 0; i < NUM_TESOUROS; i++) {
        int x, y;
        int posicao_ocupada;
        
        do {
            x = rand() % TAMANHO_GRID;
            y = rand() % TAMANHO_GRID;
            
            // Verificar se posição já está ocupada
            posicao_ocupada = 0;
            
            // Não colocar tesouro na posição inicial (0,0)
            if (x == 0 && y == 0) {
                posicao_ocupada = 1;
            }
            
            // Verificar outros tesouros
            for (int j = 0; j < i; j++) {
                if (jogo->tesouros[j].posicao.x == x && jogo->tesouros[j].posicao.y == y) {
                    posicao_ocupada = 1;
                    break;
                }
            }
        } while (posicao_ocupada);
        
        jogo->tesouros[i].posicao.x = x;
        jogo->tesouros[i].posicao.y = y;
        jogo->tesouros[i].encontrado = 0;
        
        // Definir nome e tipo do arquivo
        if (i < 3) {
            // Primeiros 3 são textos
            snprintf(jogo->tesouros[i].nome_arquivo, sizeof(jogo->tesouros[i].nome_arquivo),
                     "%d.txt", i + 1);
            jogo->tesouros[i].tipo = TESOURO_TEXTO;
        } else if (i < 6) {
            // Próximos 3 são imagens
            snprintf(jogo->tesouros[i].nome_arquivo, sizeof(jogo->tesouros[i].nome_arquivo),
                     "%d.jpg", i + 1);
            jogo->tesouros[i].tipo = TESOURO_IMAGEM;
        } else {
            // Últimos 2 são vídeos
            snprintf(jogo->tesouros[i].nome_arquivo, sizeof(jogo->tesouros[i].nome_arquivo),
                     "%d.mp4", i + 1);
            jogo->tesouros[i].tipo = TESOURO_VIDEO;
        }
        
        // Caminho completo
        snprintf(jogo->tesouros[i].caminho_completo, sizeof(jogo->tesouros[i].caminho_completo),
                 "./objetos/%s", jogo->tesouros[i].nome_arquivo);
        
        // Obter tamanho do arquivo
        jogo->tesouros[i].tamanho = obter_tamanho_arquivo(jogo->tesouros[i].caminho_completo);
        
        printf("Tesouro %d: %s na posição (%d,%d) - %lu bytes\n",
               i + 1, jogo->tesouros[i].nome_arquivo, x, y, jogo->tesouros[i].tamanho);
    }
}

int mover_jogador(estado_jogo_t* jogo, tipo_msg_t direcao) {
    if (!jogo) return -1;
    
    posicao_t nova_posicao = jogo->posicao_jogador;
    
    switch (direcao) {
        case TIPO_DESLOCA_DIREITA:
            nova_posicao.x++;
            break;
        case TIPO_DESLOCA_ESQUERDA:
            nova_posicao.x--;
            break;
        case TIPO_DESLOCA_CIMA:
            nova_posicao.y++;
            break;
        case TIPO_DESLOCA_BAIXO:
            nova_posicao.y--;
            break;
        default:
            return -1;
    }
    
    // Verificar limites do grid
    if (nova_posicao.x < 0 || nova_posicao.x >= TAMANHO_GRID ||
        nova_posicao.y < 0 || nova_posicao.y >= TAMANHO_GRID) {
        return -1; // Movimento inválido
    }
    
    // Atualizar posição
    jogo->posicao_jogador = nova_posicao;
    jogo->grid_visitado[nova_posicao.x][nova_posicao.y] = 1;
    
    return 0; // Movimento válido
}

int verificar_tesouro(estado_jogo_t* jogo, posicao_t posicao) {
    if (!jogo) return -1;
    
    for (int i = 0; i < NUM_TESOUROS; i++) {
        if (jogo->tesouros[i].posicao.x == posicao.x &&
            jogo->tesouros[i].posicao.y == posicao.y &&
            !jogo->tesouros[i].encontrado) {
            
            jogo->tesouros[i].encontrado = 1;
            jogo->tesouros_encontrados++;
            return i; // Índice do tesouro encontrado
        }
    }
    
    return -1; // Nenhum tesouro encontrado
}

void mostrar_mapa_servidor(estado_jogo_t* jogo) {
    if (!jogo) return;
    
    printf("\n=== MAPA DO SERVIDOR ===\n");
    printf("Posição do jogador: (%d,%d)\n", jogo->posicao_jogador.x, jogo->posicao_jogador.y);
    printf("Tesouros encontrados: %d/%d\n", jogo->tesouros_encontrados, NUM_TESOUROS);
    
    printf("\nLegenda: 🧍 = Jogador, 💎 = Tesouro, ❌ = Tesouro encontrado, 👣 = Visitado, ⬜ = Vazio\n");
    
    // Mostrar grid (y crescente para cima)
    for (int y = TAMANHO_GRID - 1; y >= 0; y--) {
        printf("%d ", y);
        for (int x = 0; x < TAMANHO_GRID; x++) {
            if (jogo->posicao_jogador.x == x && jogo->posicao_jogador.y == y) {
                printf("🧍 ");
            } else {
                // Verificar se há tesouro nesta posição
                int tem_tesouro = 0;
                for (int i = 0; i < NUM_TESOUROS; i++) {
                    if (jogo->tesouros[i].posicao.x == x && jogo->tesouros[i].posicao.y == y) {
                        if (jogo->tesouros[i].encontrado) {
                            printf("❌ ");
                        } else {
                            printf("💎 ");
                        }
                        tem_tesouro = 1;
                        break;
                    }
                }
                
                if (!tem_tesouro) {
                    if (jogo->grid_visitado[x][y]) {
                        printf("👣 ");
                    } else {
                        printf("⬜ ");
                    }
                }
            }
        }
        printf("\n");
    }
    
    printf("  ");
    for (int x = 0; x < TAMANHO_GRID; x++) {
        printf("%d ", x);
    }
    printf("\n========================\n");
}

unsigned long obter_tamanho_arquivo(const char* caminho) {
    if (!caminho) return 0;
    
    struct stat st;
    if (stat(caminho, &st) == 0) {
        return st.st_size;
    }
    return 0;
}

unsigned long obter_espaco_livre(const char* diretorio) {
    if (!diretorio) return 0;
    
    struct statvfs st;
    if (statvfs(diretorio, &st) == 0) {
        return st.f_bavail * st.f_frsize;
    }
    return 0;
}

int is_arquivo_regular(const char* caminho) {
    if (!caminho) return 0;
    
    struct stat st;
    if (stat(caminho, &st) == 0) {
        return S_ISREG(st.st_mode);
    }
    return 0;
}

tipo_msg_t determinar_tipo_arquivo(const char* nome_arquivo) {
    if (!nome_arquivo) return TIPO_TEXTO_ACK_NOME;
    
    const char* extensao = strrchr(nome_arquivo, '.');
    if (!extensao) return TIPO_TEXTO_ACK_NOME;
    
    if (strcasecmp(extensao, ".txt") == 0) {
        return TIPO_TEXTO_ACK_NOME;
    } else if (strcasecmp(extensao, ".jpg") == 0 || strcasecmp(extensao, ".jpeg") == 0) {
        return TIPO_IMAGEM_ACK_NOME;
    } else if (strcasecmp(extensao, ".mp4") == 0 || strcasecmp(extensao, ".mp3") == 0) {
        return TIPO_VIDEO_ACK_NOME;
    }
    
    return TIPO_TEXTO_ACK_NOME;
}
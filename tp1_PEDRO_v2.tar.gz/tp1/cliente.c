#include "protocolo.h"

#define DIRETORIO_TESOUROS "./objetos/"

// Estrutura para o estado do cliente
typedef struct {
    estado_protocolo_t protocolo;
    mapa_cliente_t mapa_atual;
    int jogo_ativo;
    int tesouros_coletados;
} estado_cliente_t;

// Protótipos das funções
int conectar_servidor(estado_cliente_t* cliente, const char* ip_servidor, int porta);
int iniciar_jogo(estado_cliente_t* cliente);
void mostrar_mapa_cliente(estado_cliente_t* cliente);
void mostrar_menu_movimento();
int processar_comando_movimento(estado_cliente_t* cliente, int comando);
int enviar_movimento(estado_cliente_t* cliente, tipo_msg_t tipo_movimento);
int processar_resposta_servidor(estado_cliente_t* cliente);
int receber_tesouro(estado_cliente_t* cliente);
int receber_arquivo_tesouro(estado_cliente_t* cliente, const char* nome_arquivo, tipo_msg_t tipo);
void exibir_tesouro(const char* nome_arquivo, const char* caminho_completo);
void limpar_tela();
const char* obter_nome_direcao(tipo_msg_t tipo);

int main(int argc, char* argv[]) {
    estado_cliente_t cliente;
    char ip_servidor[16];
    int porta_servidor = 12345;
    
    // Limpar estrutura do cliente
    memset(&cliente, 0, sizeof(cliente));
    
    printf("=== CLIENTE CAÇA AO TESOURO ===\n");
    
    // Obter IP do servidor
    if (argc > 1) {
        strcpy(ip_servidor, argv[1]);
    } else {
        printf("Digite o IP do servidor: ");
        if (scanf("%15s", ip_servidor) != 1) {
            fprintf(stderr, "Erro ao ler IP do servidor\n");
            return 1;
        }
    }
    
    // Conectar ao servidor
    if (conectar_servidor(&cliente, ip_servidor, porta_servidor) < 0) {
        fprintf(stderr, "Erro ao conectar ao servidor\n");
        return 1;
    }
    
    printf("Conectado ao servidor %s:%d\n", ip_servidor, porta_servidor);
    
    // Criar diretório de tesouros se não existir
    system("mkdir -p " DIRETORIO_TESOUROS);
    
    // Iniciar jogo
    if (iniciar_jogo(&cliente) < 0) {
        fprintf(stderr, "Erro ao iniciar jogo\n");
        close(cliente.protocolo.socket_fd);
        return 1;
    }
    
    printf("🎮 Jogo iniciado! Encontre todos os tesouros escondidos no mapa 8x8!\n");
    printf("Pressione ENTER para continuar...");
    getchar(); // Limpar buffer
    getchar(); // Aguardar ENTER
    
    // Loop principal do jogo
    while (cliente.jogo_ativo) {
        limpar_tela();
        mostrar_mapa_cliente(&cliente);
        mostrar_menu_movimento();
        
        int comando;
        printf("Digite sua escolha: ");
        
        if (scanf("%d", &comando) != 1) {
            printf("Comando inválido! Pressione ENTER para continuar...");
            getchar();
            getchar();
            continue;
        }
        
        if (comando == 0) {
            printf("Saindo do jogo...\n");
            break;
        }
        
        if (processar_comando_movimento(&cliente, comando) < 0) {
            printf("Erro ao processar movimento! Pressione ENTER para continuar...");
            getchar();
            getchar();
        }
    }
    
    close(cliente.protocolo.socket_fd);
    printf("Obrigado por jogar! 🎉\n");
    return 0;
}

int conectar_servidor(estado_cliente_t* cliente, const char* ip_servidor, int porta) {
    // Criar socket UDP
    cliente->protocolo.socket_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (cliente->protocolo.socket_fd < 0) {
        perror("Erro ao criar socket");
        return -1;
    }
    
    // Configurar endereço do servidor
    memset(&cliente->protocolo.endereco_remoto, 0, sizeof(cliente->protocolo.endereco_remoto));
    cliente->protocolo.endereco_remoto.sin_family = AF_INET;
    cliente->protocolo.endereco_remoto.sin_port = htons(porta);
    
    if (inet_pton(AF_INET, ip_servidor, &cliente->protocolo.endereco_remoto.sin_addr) <= 0) {
        fprintf(stderr, "Endereço IP inválido: %s\n", ip_servidor);
        close(cliente->protocolo.socket_fd);
        return -1;
    }
    
    // Inicializar estado do protocolo
    cliente->protocolo.seq_atual = 0;
    cliente->protocolo.seq_esperada = 0;
    cliente->protocolo.tamanho_endereco = sizeof(cliente->protocolo.endereco_remoto);
    
    return 0;
}

int iniciar_jogo(estado_cliente_t* cliente) {
    // Enviar comando para iniciar jogo
    frame_t frame_inicio;
    criar_frame(&frame_inicio, cliente->protocolo.seq_atual, TIPO_INICIAR_JOGO, NULL, 0);
    
    if (enviar_frame(&cliente->protocolo, &frame_inicio) < 0) {
        printf("Erro ao enviar comando de início\n");
        return -1;
    }
    
    // Aguardar ACK do servidor
    if (esperar_ack(&cliente->protocolo) < 0) {
        printf("Servidor não confirmou início do jogo\n");
        return -1;
    }
    
    // Receber mapa inicial
    frame_t frame_mapa;
    if (receber_frame(&cliente->protocolo, &frame_mapa) < 0) {
        printf("Erro ao receber mapa inicial\n");
        return -1;
    }
    
    if (frame_mapa.tipo != TIPO_MAPA_CLIENTE) {
        printf("Resposta inesperada do servidor\n");
        return -1;
    }
    
    // Copiar dados do mapa
    memcpy(&cliente->mapa_atual, frame_mapa.dados, sizeof(mapa_cliente_t));
    cliente->jogo_ativo = 1;
    cliente->tesouros_coletados = cliente->mapa_atual.tesouros_encontrados;
    
    return 0;
}

void mostrar_mapa_cliente(estado_cliente_t* cliente) {
    printf("\n=== MAPA DO CAÇA AO TESOURO ===\n");
    printf("Posição atual: (%d,%d)\n", 
           cliente->mapa_atual.posicao_jogador.x, 
           cliente->mapa_atual.posicao_jogador.y);
    printf("Tesouros encontrados: %d/8\n", cliente->mapa_atual.tesouros_encontrados);
    
    printf("\nLegenda: 🧍 = Você, 💎 = Tesouro encontrado, 👣 = Visitado, ⬜ = Inexplorado\n");
    printf("────────────────────────────────────────\n");
    
    // Mostrar grid (y crescente para cima)
    for (int y = TAMANHO_GRID - 1; y >= 0; y--) {
        printf("%d │", y);
        for (int x = 0; x < TAMANHO_GRID; x++) {
            if (cliente->mapa_atual.posicao_jogador.x == x && 
                cliente->mapa_atual.posicao_jogador.y == y) {
                printf(" 🧍");
            } else if (cliente->mapa_atual.grid_tesouros[x][y]) {
                printf(" 💎");
            } else if (cliente->mapa_atual.grid_visitado[x][y]) {
                printf(" 👣");
            } else {
                printf(" ⬜");
            }
        }
        printf("\n");
    }
    
    printf("  └");
    for (int i = 0; i < TAMANHO_GRID; i++) {
        printf("───");
    }
    printf("\n   ");
    for (int x = 0; x < TAMANHO_GRID; x++) {
        printf(" %d ", x);
    }
    printf("\n────────────────────────────────────────\n");
}

void mostrar_menu_movimento() {
    printf("\n=== MOVIMENTOS DISPONÍVEIS ===\n");
    printf("1. ⬆️  Mover para CIMA\n");
    printf("2. ⬇️  Mover para BAIXO\n");
    printf("3. ⬅️  Mover para ESQUERDA\n");
    printf("4. ➡️  Mover para DIREITA\n");
    printf("0. 🚪 Sair do jogo\n");
    printf("═══════════════════════════════\n");
}

int processar_comando_movimento(estado_cliente_t* cliente, int comando) {
    tipo_msg_t tipo_movimento;
    
    switch (comando) {
        case 1:
            tipo_movimento = TIPO_DESLOCA_CIMA;
            break;
        case 2:
            tipo_movimento = TIPO_DESLOCA_BAIXO;
            break;
        case 3:
            tipo_movimento = TIPO_DESLOCA_ESQUERDA;
            break;
        case 4:
            tipo_movimento = TIPO_DESLOCA_DIREITA;
            break;
        default:
            printf("Comando inválido!\n");
            return -1;
    }
    
    printf("Enviando movimento: %s...\n", obter_nome_direcao(tipo_movimento));
    
    // Enviar movimento para o servidor
    if (enviar_movimento(cliente, tipo_movimento) < 0) {
        return -1;
    }
    
    // Processar resposta do servidor
    return processar_resposta_servidor(cliente);
}

int enviar_movimento(estado_cliente_t* cliente, tipo_msg_t tipo_movimento) {
    frame_t frame_movimento;
    cliente->protocolo.seq_atual = (cliente->protocolo.seq_atual + 1) % 32;
    
    criar_frame(&frame_movimento, cliente->protocolo.seq_atual, tipo_movimento, NULL, 0);
    
    return enviar_frame(&cliente->protocolo, &frame_movimento);
}

int processar_resposta_servidor(estado_cliente_t* cliente) {
    frame_t frame_resposta;
    
    // Receber resposta do servidor
    int result = receber_frame(&cliente->protocolo, &frame_resposta);
    if (result < 0) {
        if (result == -2) {
            printf("Timeout - servidor não respondeu\n");
        } else {
            printf("Erro ao receber resposta do servidor\n");
        }
        return -1;
    }
    
    switch (frame_resposta.tipo) {
        case TIPO_ERRO:
            if (frame_resposta.dados[0] == ERRO_MOVIMENTO_INVALIDO) {
                printf("❌ Movimento inválido! Você não pode sair do mapa.\n");
            } else {
                printf("❌ Erro do servidor: %d\n", frame_resposta.dados[0]);
            }
            printf("Pressione ENTER para continuar...");
            getchar();
            getchar();
            return 0;
            
        case TIPO_MAPA_CLIENTE:
            // Atualizar mapa
            memcpy(&cliente->mapa_atual, frame_resposta.dados, sizeof(mapa_cliente_t));
            printf("✅ Movimento realizado!\n");
            
            // Verificar se encontrou novos tesouros
            if (cliente->mapa_atual.tesouros_encontrados > cliente->tesouros_coletados) {
                printf("🎉 Você se moveu para uma nova posição!\n");
                cliente->tesouros_coletados = cliente->mapa_atual.tesouros_encontrados;
            }
            
            printf("Pressione ENTER para continuar...");
            getchar();
            getchar();
            return 0;
            
        case TIPO_TESOURO_ENCONTRADO:
            printf("🏆 TESOURO ENCONTRADO! 🏆\n");
            return receber_tesouro(cliente);
            
        case TIPO_FIM_JOGO:
            printf("\n🎉🎉🎉 PARABÉNS! VOCÊ ENCONTROU TODOS OS TESOUROS! 🎉🎉🎉\n");
            printf("Pressione ENTER para continuar...");
            getchar();
            getchar();
            cliente->jogo_ativo = 0;
            return 0;
            
        default:
            printf("Resposta inesperada do servidor: tipo %d\n", frame_resposta.tipo);
            return -1;
    }
}

int receber_tesouro(estado_cliente_t* cliente) {
    // Já recebemos o frame TIPO_TESOURO_ENCONTRADO
    // Primeiro byte é o tipo, resto é o nome do arquivo
    frame_t frame_tesouro;
    if (receber_frame(&cliente->protocolo, &frame_tesouro) < 0) {
        printf("Erro ao receber informações do tesouro\n");
        return -1;
    }
    
    tipo_tesouro_t tipo_tesouro = (tipo_tesouro_t)frame_tesouro.dados[0];
    char nome_arquivo[64];
    memcpy(nome_arquivo, frame_tesouro.dados + 1, frame_tesouro.tamanho - 1);
    nome_arquivo[frame_tesouro.tamanho - 1] = '\0';
    
    printf("Tipo: ");
    switch (tipo_tesouro) {
        case TESOURO_TEXTO:
            printf("📄 Texto");
            break;
        case TESOURO_IMAGEM:
            printf("🖼️  Imagem");
            break;
        case TESOURO_VIDEO:
            printf("🎥 Vídeo");
            break;
    }
    printf(" - Arquivo: %s\n", nome_arquivo);
    
    // Enviar ACK
    enviar_ack(&cliente->protocolo, frame_tesouro.sequencia);
    
    // Determinar tipo de protocolo baseado no tipo do tesouro
    tipo_msg_t tipo_protocolo;
    switch (tipo_tesouro) {
        case TESOURO_TEXTO:
            tipo_protocolo = TIPO_TEXTO_ACK_NOME;
            break;
        case TESOURO_IMAGEM:
            tipo_protocolo = TIPO_IMAGEM_ACK_NOME;
            break;
        case TESOURO_VIDEO:
            tipo_protocolo = TIPO_VIDEO_ACK_NOME;
            break;
        default:
            tipo_protocolo = TIPO_TEXTO_ACK_NOME;
    }
    
    // Receber arquivo do tesouro
    if (receber_arquivo_tesouro(cliente, nome_arquivo, tipo_protocolo) < 0) {
        printf("Erro ao receber arquivo do tesouro\n");
        return -1;
    }
    
    // Receber mapa atualizado
    frame_t frame_mapa;
    if (receber_frame(&cliente->protocolo, &frame_mapa) < 0) {
        printf("Erro ao receber mapa atualizado\n");
        return -1;
    }
    
    if (frame_mapa.tipo == TIPO_MAPA_CLIENTE) {
        memcpy(&cliente->mapa_atual, frame_mapa.dados, sizeof(mapa_cliente_t));
        cliente->tesouros_coletados = cliente->mapa_atual.tesouros_encontrados;
    }
    
    printf("Pressione ENTER para continuar...");
    getchar();
    getchar();
    
    return 0;
}

int receber_arquivo_tesouro(estado_cliente_t* cliente, const char* nome_arquivo, tipo_msg_t tipo) {
    FILE* arquivo_tesouro = NULL;
    char caminho_completo[512];
    unsigned long tamanho_esperado = 0;
    unsigned long bytes_recebidos = 0;
    frame_t frame_recebido;
    int estado_recepcao = 0; // 0=nome, 1=tamanho, 2=dados
    
    printf("Recebendo tesouro: %s\n", nome_arquivo);
    
    // Criar caminho completo
    snprintf(caminho_completo, sizeof(caminho_completo), 
             "%s%s", DIRETORIO_TESOUROS, nome_arquivo);
    
    while (estado_recepcao < 3) {
        int result = receber_frame(&cliente->protocolo, &frame_recebido);
        
        if (result < 0) {
            if (arquivo_tesouro) {
                fclose(arquivo_tesouro);
            }
            return -1;
        }
        
        switch (frame_recebido.tipo) {
            case TIPO_TEXTO_ACK_NOME:
            case TIPO_IMAGEM_ACK_NOME:
            case TIPO_VIDEO_ACK_NOME:
                if (estado_recepcao == 0) {
                    // Confirmar nome
                    enviar_ack(&cliente->protocolo, frame_recebido.sequencia);
                    estado_recepcao = 1;
                }
                break;
                
            case TIPO_TAMANHO:
                if (estado_recepcao == 1) {
                    // Receber tamanho
                    tamanho_esperado = (frame_recebido.dados[0] << 24) |
                                     (frame_recebido.dados[1] << 16) |
                                     (frame_recebido.dados[2] << 8) |
                                     frame_recebido.dados[3];
                    
                    printf("Tamanho do tesouro: %lu bytes\n", tamanho_esperado);
                    
                    // Abrir arquivo para escrita
                    arquivo_tesouro = fopen(caminho_completo, "wb");
                    if (!arquivo_tesouro) {
                        perror("Erro ao criar arquivo de tesouro");
                        enviar_erro(&cliente->protocolo, frame_recebido.sequencia, ERRO_SEM_PERMISSAO);
                        return -1;
                    }
                    
                    enviar_ack(&cliente->protocolo, frame_recebido.sequencia);
                    estado_recepcao = 2;
                    bytes_recebidos = 0;
                }
                break;
                
            case TIPO_DADOS:
                if (estado_recepcao == 2 && arquivo_tesouro) {
                    // Escrever dados
                    size_t bytes_escritos = fwrite(frame_recebido.dados, 1, 
                                                  frame_recebido.tamanho, arquivo_tesouro);
                    
                    if (bytes_escritos != frame_recebido.tamanho) {
                        printf("Erro ao escrever dados do tesouro\n");
                        enviar_nack(&cliente->protocolo, frame_recebido.sequencia);
                        fclose(arquivo_tesouro);
                        return -1;
                    }
                    
                    bytes_recebidos += bytes_escritos;
                    
                    // Mostrar progresso
                    if (tamanho_esperado > 0) {
                        printf("Progresso: %.1f%% (%lu/%lu bytes)\r", 
                               (double)bytes_recebidos / tamanho_esperado * 100.0,
                               bytes_recebidos, tamanho_esperado);
                        fflush(stdout);
                    }
                    
                    enviar_ack(&cliente->protocolo, frame_recebido.sequencia);
                }
                break;
                
            case TIPO_FIM_ARQUIVO:
                if (estado_recepcao == 2) {
                    printf("\n✅ Tesouro recebido com sucesso!\n");
                    printf("Total de bytes: %lu\n", bytes_recebidos);
                    
                    if (arquivo_tesouro) {
                        fclose(arquivo_tesouro);
                        arquivo_tesouro = NULL;
                    }
                    
                    // Exibir tesouro baseado no tipo
                    exibir_tesouro(nome_arquivo, caminho_completo);
                    
                    enviar_ack(&cliente->protocolo, frame_recebido.sequencia);
                    estado_recepcao = 3; // Finalizado
                }
                break;
                
            case TIPO_ERRO:
                printf("Erro ao receber tesouro: %d\n", frame_recebido.dados[0]);
                if (arquivo_tesouro) {
                    fclose(arquivo_tesouro);
                }
                return -1;
        }
    }
    
    return 0;
}

void exibir_tesouro(const char* nome_arquivo, const char* caminho_completo) {
    const char* extensao = strrchr(nome_arquivo, '.');
    
    printf("\n🎁 TESOURO COLETADO: %s\n", nome_arquivo);
    printf("📁 Salvo em: %s\n", caminho_completo);
    
    if (extensao) {
        if (strcasecmp(extensao, ".txt") == 0) {
            printf("📄 Arquivo de texto - Conteúdo:\n");
            printf("═══════════════════════════════════════\n");
            
            FILE* arquivo = fopen(caminho_completo, "r");
            if (arquivo) {
                char linha[1024];
                int linhas_mostradas = 0;
                
                while (fgets(linha, sizeof(linha), arquivo) && linhas_mostradas < 10) {
                    printf("%s", linha);
                    linhas_mostradas++;
                }
                
                if (linhas_mostradas >= 10) {
                    printf("... (arquivo continua)\n");
                }
                
                fclose(arquivo);
            }
            printf("═══════════════════════════════════════\n");
            
        } else if (strcasecmp(extensao, ".jpg") == 0 || strcasecmp(extensao, ".jpeg") == 0) {
            printf("🖼️  Arquivo de imagem JPG recebido!\n");
            printf("📝 Dica: Use um visualizador de imagens para ver o tesouro!\n");
            
        } else if (strcasecmp(extensao, ".mp4") == 0) {
            printf("🎥 Arquivo de vídeo MP4 recebido!\n");
            printf("📝 Dica: Use um player de vídeo para assistir ao tesouro!\n");
        }
    }
}

void limpar_tela() {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

const char* obter_nome_direcao(tipo_msg_t tipo) {
    switch (tipo) {
        case TIPO_DESLOCA_CIMA: return "CIMA";
        case TIPO_DESLOCA_BAIXO: return "BAIXO";
        case TIPO_DESLOCA_ESQUERDA: return "ESQUERDA";
        case TIPO_DESLOCA_DIREITA: return "DIREITA";
        default: return "DESCONHECIDO";
    }
}